﻿namespace TH02
{
    partial class form_paycs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_paycs));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txt_voucher = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_money = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_dc = new System.Windows.Forms.TextBox();
            this.cb_pttt = new System.Windows.Forms.ComboBox();
            this.dt_tggh = new System.Windows.Forms.DateTimePicker();
            this.btn_apply = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_dth = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_voucher = new System.Windows.Forms.Label();
            this.pt_voucher = new System.Windows.Forms.PictureBox();
            this.txt_tongtien = new System.Windows.Forms.TextBox();
            this.IDDH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_voucher)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1002, 315);
            this.dataGridView1.TabIndex = 1;
            // 
            // txt_voucher
            // 
            this.txt_voucher.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_voucher.Location = new System.Drawing.Point(395, 444);
            this.txt_voucher.Name = "txt_voucher";
            this.txt_voucher.Size = new System.Drawing.Size(392, 30);
            this.txt_voucher.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(238, 449);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "Mã khuyến mãi:";
            // 
            // btn_money
            // 
            this.btn_money.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_money.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_money.FlatAppearance.BorderSize = 0;
            this.btn_money.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_money.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_money.ForeColor = System.Drawing.Color.White;
            this.btn_money.Image = ((System.Drawing.Image)(resources.GetObject("btn_money.Image")));
            this.btn_money.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_money.Location = new System.Drawing.Point(421, 551);
            this.btn_money.Name = "btn_money";
            this.btn_money.Size = new System.Drawing.Size(198, 38);
            this.btn_money.TabIndex = 7;
            this.btn_money.Text = "Thanh toán";
            this.btn_money.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_money.UseVisualStyleBackColor = false;
            this.btn_money.Click += new System.EventHandler(this.btn_money_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(199, 413);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Thời gian giao hàng:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(221, 375);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Địa chỉ giao hàng:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(170, 341);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(219, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Phương thức thanh toán";
            // 
            // txt_dc
            // 
            this.txt_dc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dc.Location = new System.Drawing.Point(395, 372);
            this.txt_dc.Name = "txt_dc";
            this.txt_dc.Size = new System.Drawing.Size(392, 30);
            this.txt_dc.TabIndex = 9;
            this.txt_dc.Text = "Q1 TPHCM";
            // 
            // cb_pttt
            // 
            this.cb_pttt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_pttt.FormattingEnabled = true;
            this.cb_pttt.Items.AddRange(new object[] {
            "Tiền mặt",
            "Ví điện tử",
            "Tài khoản ngân hàng"});
            this.cb_pttt.Location = new System.Drawing.Point(395, 333);
            this.cb_pttt.Name = "cb_pttt";
            this.cb_pttt.Size = new System.Drawing.Size(392, 33);
            this.cb_pttt.TabIndex = 10;
            this.cb_pttt.Text = "Tiền mặt";
            // 
            // dt_tggh
            // 
            this.dt_tggh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dt_tggh.Location = new System.Drawing.Point(395, 408);
            this.dt_tggh.Name = "dt_tggh";
            this.dt_tggh.Size = new System.Drawing.Size(392, 30);
            this.dt_tggh.TabIndex = 11;
            // 
            // btn_apply
            // 
            this.btn_apply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_apply.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_apply.FlatAppearance.BorderSize = 0;
            this.btn_apply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_apply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_apply.ForeColor = System.Drawing.Color.White;
            this.btn_apply.Image = ((System.Drawing.Image)(resources.GetObject("btn_apply.Image")));
            this.btn_apply.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_apply.Location = new System.Drawing.Point(793, 440);
            this.btn_apply.Name = "btn_apply";
            this.btn_apply.Size = new System.Drawing.Size(198, 38);
            this.btn_apply.TabIndex = 7;
            this.btn_apply.Text = "Áp dụng";
            this.btn_apply.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_apply.UseVisualStyleBackColor = false;
            this.btn_apply.Click += new System.EventHandler(this.btn_apply_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(289, 518);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Tổng tiền:";
            // 
            // txt_dth
            // 
            this.txt_dth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dth.Location = new System.Drawing.Point(395, 479);
            this.txt_dth.Name = "txt_dth";
            this.txt_dth.Size = new System.Drawing.Size(392, 30);
            this.txt_dth.TabIndex = 9;
            this.txt_dth.Text = "098123456";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(257, 484);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Số điện thoại:";
            // 
            // lb_voucher
            // 
            this.lb_voucher.AutoSize = true;
            this.lb_voucher.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_voucher.ForeColor = System.Drawing.Color.Yellow;
            this.lb_voucher.Location = new System.Drawing.Point(64, 558);
            this.lb_voucher.Name = "lb_voucher";
            this.lb_voucher.Size = new System.Drawing.Size(70, 25);
            this.lb_voucher.TabIndex = 12;
            this.lb_voucher.Text = "label7";
            this.lb_voucher.Visible = false;
            this.lb_voucher.Click += new System.EventHandler(this.label7_Click);
            // 
            // pt_voucher
            // 
            this.pt_voucher.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_voucher.BackgroundImage")));
            this.pt_voucher.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pt_voucher.Location = new System.Drawing.Point(12, 539);
            this.pt_voucher.Name = "pt_voucher";
            this.pt_voucher.Size = new System.Drawing.Size(46, 50);
            this.pt_voucher.TabIndex = 13;
            this.pt_voucher.TabStop = false;
            this.pt_voucher.Visible = false;
            // 
            // txt_tongtien
            // 
            this.txt_tongtien.Enabled = false;
            this.txt_tongtien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tongtien.Location = new System.Drawing.Point(395, 515);
            this.txt_tongtien.Name = "txt_tongtien";
            this.txt_tongtien.Size = new System.Drawing.Size(392, 30);
            this.txt_tongtien.TabIndex = 9;
            this.txt_tongtien.TextChanged += new System.EventHandler(this.txt_tongtien_TextChanged);
            // 
            // IDDH
            // 
            this.IDDH.DataPropertyName = "IDDH";
            this.IDDH.HeaderText = "Mã đơn hàng";
            this.IDDH.MinimumWidth = 6;
            this.IDDH.Name = "IDDH";
            this.IDDH.ReadOnly = true;
            this.IDDH.Width = 158;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "Mã điện thoại";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 158;
            // 
            // form_paycs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(193)))), ((int)(((byte)(150)))));
            this.ClientSize = new System.Drawing.Size(1023, 610);
            this.Controls.Add(this.pt_voucher);
            this.Controls.Add(this.lb_voucher);
            this.Controls.Add(this.dt_tggh);
            this.Controls.Add(this.cb_pttt);
            this.Controls.Add(this.txt_dc);
            this.Controls.Add(this.txt_dth);
            this.Controls.Add(this.txt_tongtien);
            this.Controls.Add(this.txt_voucher);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_apply);
            this.Controls.Add(this.btn_money);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_paycs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thanh toán";
            this.Load += new System.EventHandler(this.form_paycs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_voucher)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txt_voucher;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_money;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_dc;
        private System.Windows.Forms.ComboBox cb_pttt;
        private System.Windows.Forms.DateTimePicker dt_tggh;
        private System.Windows.Forms.Button btn_apply;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_dth;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_voucher;
        private System.Windows.Forms.PictureBox pt_voucher;
        private System.Windows.Forms.TextBox txt_tongtien;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDDH;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
    }
}