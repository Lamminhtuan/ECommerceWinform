﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class form_cart : Form
    {
        DataTable dt;
        string iddh = cart.GetID();
        public form_cart()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void form_cart_Load(object sender, EventArgs e)
        {
            
            dt = cart_chitiet.get(iddh);
            if (dt.Rows.Count > 0)
                dt.Columns.Remove("IDDH");
            dataGridView1.DataSource = dt;

            CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
            string gia = String.Format(cul, "{0:c}", cart_chitiet.gettongtien(iddh));
            txt_tongtien.Text = gia;
            if (dt.Rows.Count > 0)
                num_sl.DataBindings.Add("value", dt, "Soluong");
            else
            {

            }
        }

        private void btn_money_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {
                form_paycs pay = new form_paycs();
                pay.iddh = iddh;
                pay.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Chưa có sản phẩm!");
            }
        }

        private void txt_tongtien_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {
                int irow = dataGridView1.CurrentCell.RowIndex;
                string index = dataGridView1.Rows[irow].Cells["ID"].Value.ToString();
                cart_chitiet.Xoa(iddh, index);
                
            }
            dt = cart_chitiet.get(iddh);
            dt.Columns.Remove("IDDH");
            dataGridView1.DataSource = dt;
        }

        private void btn_sl_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {
                int irow = dataGridView1.CurrentCell.RowIndex;
                int index = Convert.ToInt32(dataGridView1.Rows[irow].Cells["ID"].Value);
                
                int sl = Convert.ToInt32(num_sl.Value.ToString());
                cart_chitiet.UpdateSL(iddh, index, sl); 
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
                string gia = String.Format(cul, "{0:c}", cart_chitiet.gettongtien(iddh));
                txt_tongtien.Text = gia;
            }
            dt = cart_chitiet.get(iddh);
            dt.Columns.Remove("IDDH");
            dataGridView1.DataSource = dt;
        }
    }
}
