﻿namespace TH02
{
    partial class form_phone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_phone));
            this.lb_screen = new System.Windows.Forms.Label();
            this.pt_phone = new System.Windows.Forms.PictureBox();
            this.il_phones = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.lb_os = new System.Windows.Forms.Label();
            this.lb_camera = new System.Windows.Forms.Label();
            this.lb_selfie = new System.Windows.Forms.Label();
            this.lb_chip = new System.Windows.Forms.Label();
            this.lb_ram = new System.Windows.Forms.Label();
            this.lb_rom = new System.Windows.Forms.Label();
            this.lb_pin = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_gia = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.num_sl = new System.Windows.Forms.NumericUpDown();
            this.dt_cmts = new System.Windows.Forms.DataGridView();
            this.cmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Danhgia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label9 = new System.Windows.Forms.Label();
            this.ptb_fstar1 = new System.Windows.Forms.PictureBox();
            this.ptb_fstar2 = new System.Windows.Forms.PictureBox();
            this.ptb_fstar3 = new System.Windows.Forms.PictureBox();
            this.ptb_fstar4 = new System.Windows.Forms.PictureBox();
            this.ptb_fstar5 = new System.Windows.Forms.PictureBox();
            this.ptb_hstar5 = new System.Windows.Forms.PictureBox();
            this.ptb_hstar4 = new System.Windows.Forms.PictureBox();
            this.ptb_hstar3 = new System.Windows.Forms.PictureBox();
            this.ptb_hstar2 = new System.Windows.Forms.PictureBox();
            this.ptb_hstar1 = new System.Windows.Forms.PictureBox();
            this.lb_review = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pt_phone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_sl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_cmts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_screen
            // 
            this.lb_screen.AutoSize = true;
            this.lb_screen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_screen.Location = new System.Drawing.Point(650, 38);
            this.lb_screen.Name = "lb_screen";
            this.lb_screen.Size = new System.Drawing.Size(72, 20);
            this.lb_screen.TabIndex = 0;
            this.lb_screen.Text = "lb_name";
            // 
            // pt_phone
            // 
            this.pt_phone.Location = new System.Drawing.Point(22, 12);
            this.pt_phone.Name = "pt_phone";
            this.pt_phone.Size = new System.Drawing.Size(362, 356);
            this.pt_phone.TabIndex = 1;
            this.pt_phone.TabStop = false;
            this.pt_phone.Click += new System.EventHandler(this.pt_phone_Click);
            // 
            // il_phones
            // 
            this.il_phones.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("il_phones.ImageStream")));
            this.il_phones.TransparentColor = System.Drawing.Color.Transparent;
            this.il_phones.Images.SetKeyName(0, "0.jpg");
            this.il_phones.Images.SetKeyName(1, "1.jpg");
            this.il_phones.Images.SetKeyName(2, "2.jpg");
            this.il_phones.Images.SetKeyName(3, "3.jpg");
            this.il_phones.Images.SetKeyName(4, "4.jpg");
            this.il_phones.Images.SetKeyName(5, "5.jpg");
            this.il_phones.Images.SetKeyName(6, "6.jpg");
            this.il_phones.Images.SetKeyName(7, "7.jpg");
            this.il_phones.Images.SetKeyName(8, "8.jpg");
            this.il_phones.Images.SetKeyName(9, "9.jpg");
            this.il_phones.Images.SetKeyName(10, "10.jpg");
            this.il_phones.Images.SetKeyName(11, "11.jpg");
            this.il_phones.Images.SetKeyName(12, "12.jpg");
            this.il_phones.Images.SetKeyName(13, "13.jpg");
            this.il_phones.Images.SetKeyName(14, "14.jpg");
            this.il_phones.Images.SetKeyName(15, "15.jpg");
            this.il_phones.Images.SetKeyName(16, "16.jpg");
            this.il_phones.Images.SetKeyName(17, "17.jpg");
            this.il_phones.Images.SetKeyName(18, "18.jpg");
            this.il_phones.Images.SetKeyName(19, "19.jpg");
            this.il_phones.Images.SetKeyName(20, "20.jpg");
            this.il_phones.Images.SetKeyName(21, "21.jpg");
            this.il_phones.Images.SetKeyName(22, "22.jpg");
            this.il_phones.Images.SetKeyName(23, "23.jpg");
            this.il_phones.Images.SetKeyName(24, "24.jpg");
            this.il_phones.Images.SetKeyName(25, "25.jpg");
            this.il_phones.Images.SetKeyName(26, "26.jpg");
            this.il_phones.Images.SetKeyName(27, "27.jpg");
            this.il_phones.Images.SetKeyName(28, "28.jpg");
            this.il_phones.Images.SetKeyName(29, "29.jpg");
            this.il_phones.Images.SetKeyName(30, "30.jpg");
            this.il_phones.Images.SetKeyName(31, "31.jpg");
            this.il_phones.Images.SetKeyName(32, "32.jpg");
            this.il_phones.Images.SetKeyName(33, "33.jpg");
            this.il_phones.Images.SetKeyName(34, "34.jpg");
            this.il_phones.Images.SetKeyName(35, "35.jpg");
            this.il_phones.Images.SetKeyName(36, "36.jpg");
            this.il_phones.Images.SetKeyName(37, "37.jpg");
            this.il_phones.Images.SetKeyName(38, "38.jpg");
            this.il_phones.Images.SetKeyName(39, "39.jpg");
            this.il_phones.Images.SetKeyName(40, "40.jpg");
            this.il_phones.Images.SetKeyName(41, "41.jpg");
            this.il_phones.Images.SetKeyName(42, "42.jpg");
            this.il_phones.Images.SetKeyName(43, "43.jpg");
            this.il_phones.Images.SetKeyName(44, "44.jpg");
            this.il_phones.Images.SetKeyName(45, "45.jpg");
            this.il_phones.Images.SetKeyName(46, "46.jpg");
            this.il_phones.Images.SetKeyName(47, "47.jpg");
            this.il_phones.Images.SetKeyName(48, "48.jpg");
            this.il_phones.Images.SetKeyName(49, "49.jpg");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(469, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Màn hình";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(468, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Hệ điều hành";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(469, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Camera sau";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(468, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 29);
            this.label4.TabIndex = 2;
            this.label4.Text = "Camera trước";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(467, 312);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 29);
            this.label5.TabIndex = 2;
            this.label5.Text = "Chip";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(469, 378);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 29);
            this.label6.TabIndex = 2;
            this.label6.Text = "RAM";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(423, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 50);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(422, 104);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 50);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(422, 177);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(40, 50);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(422, 243);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(40, 50);
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(422, 312);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(40, 50);
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(469, 449);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 29);
            this.label7.TabIndex = 2;
            this.label7.Text = "ROM";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(423, 378);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(40, 50);
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Location = new System.Drawing.Point(423, 449);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(40, 50);
            this.pictureBox7.TabIndex = 3;
            this.pictureBox7.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(483, 521);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 29);
            this.label8.TabIndex = 2;
            this.label8.Text = "Pin";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Location = new System.Drawing.Point(423, 521);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(40, 50);
            this.pictureBox8.TabIndex = 3;
            this.pictureBox8.TabStop = false;
            // 
            // lb_os
            // 
            this.lb_os.AutoSize = true;
            this.lb_os.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_os.Location = new System.Drawing.Point(650, 104);
            this.lb_os.Name = "lb_os";
            this.lb_os.Size = new System.Drawing.Size(72, 20);
            this.lb_os.TabIndex = 0;
            this.lb_os.Text = "lb_name";
            // 
            // lb_camera
            // 
            this.lb_camera.AutoSize = true;
            this.lb_camera.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_camera.Location = new System.Drawing.Point(650, 177);
            this.lb_camera.Name = "lb_camera";
            this.lb_camera.Size = new System.Drawing.Size(72, 20);
            this.lb_camera.TabIndex = 0;
            this.lb_camera.Text = "lb_name";
            // 
            // lb_selfie
            // 
            this.lb_selfie.AutoSize = true;
            this.lb_selfie.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_selfie.Location = new System.Drawing.Point(650, 243);
            this.lb_selfie.Name = "lb_selfie";
            this.lb_selfie.Size = new System.Drawing.Size(72, 20);
            this.lb_selfie.TabIndex = 0;
            this.lb_selfie.Text = "lb_name";
            // 
            // lb_chip
            // 
            this.lb_chip.AutoSize = true;
            this.lb_chip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_chip.Location = new System.Drawing.Point(650, 312);
            this.lb_chip.Name = "lb_chip";
            this.lb_chip.Size = new System.Drawing.Size(72, 20);
            this.lb_chip.TabIndex = 0;
            this.lb_chip.Text = "lb_name";
            // 
            // lb_ram
            // 
            this.lb_ram.AutoSize = true;
            this.lb_ram.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ram.Location = new System.Drawing.Point(650, 378);
            this.lb_ram.Name = "lb_ram";
            this.lb_ram.Size = new System.Drawing.Size(72, 20);
            this.lb_ram.TabIndex = 0;
            this.lb_ram.Text = "lb_name";
            // 
            // lb_rom
            // 
            this.lb_rom.AutoSize = true;
            this.lb_rom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_rom.Location = new System.Drawing.Point(650, 449);
            this.lb_rom.Name = "lb_rom";
            this.lb_rom.Size = new System.Drawing.Size(72, 20);
            this.lb_rom.TabIndex = 0;
            this.lb_rom.Text = "lb_name";
            this.lb_rom.Click += new System.EventHandler(this.label14_Click);
            // 
            // lb_pin
            // 
            this.lb_pin.AutoSize = true;
            this.lb_pin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pin.Location = new System.Drawing.Point(650, 521);
            this.lb_pin.Name = "lb_pin";
            this.lb_pin.Size = new System.Drawing.Size(72, 20);
            this.lb_pin.TabIndex = 0;
            this.lb_pin.Text = "lb_name";
            this.lb_pin.Click += new System.EventHandler(this.label14_Click);
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.Location = new System.Drawing.Point(103, 385);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(64, 22);
            this.lb_name.TabIndex = 4;
            this.lb_name.Text = "label9";
            // 
            // lb_gia
            // 
            this.lb_gia.AutoSize = true;
            this.lb_gia.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_gia.Location = new System.Drawing.Point(104, 421);
            this.lb_gia.Name = "lb_gia";
            this.lb_gia.Size = new System.Drawing.Size(64, 22);
            this.lb_gia.TabIndex = 4;
            this.lb_gia.Text = "label9";
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_add.FlatAppearance.BorderSize = 0;
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.Color.White;
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_add.Location = new System.Drawing.Point(107, 481);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(198, 90);
            this.btn_add.TabIndex = 5;
            this.btn_add.Text = "Thêm vào giỏ hàng";
            this.btn_add.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // num_sl
            // 
            this.num_sl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num_sl.Location = new System.Drawing.Point(107, 454);
            this.num_sl.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.num_sl.Name = "num_sl";
            this.num_sl.Size = new System.Drawing.Size(198, 27);
            this.num_sl.TabIndex = 6;
            this.num_sl.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // dt_cmts
            // 
            this.dt_cmts.AllowUserToAddRows = false;
            this.dt_cmts.AllowUserToDeleteRows = false;
            this.dt_cmts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dt_cmts.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dt_cmts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dt_cmts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cmt,
            this.Danhgia});
            this.dt_cmts.Location = new System.Drawing.Point(12, 624);
            this.dt_cmts.Name = "dt_cmts";
            this.dt_cmts.RowHeadersWidth = 51;
            this.dt_cmts.RowTemplate.Height = 24;
            this.dt_cmts.Size = new System.Drawing.Size(1225, 181);
            this.dt_cmts.TabIndex = 7;
            this.dt_cmts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dt_cmts_CellContentClick);
            // 
            // cmt
            // 
            this.cmt.DataPropertyName = "Binhluan";
            this.cmt.HeaderText = "Bình luận";
            this.cmt.MinimumWidth = 6;
            this.cmt.Name = "cmt";
            // 
            // Danhgia
            // 
            this.Danhgia.DataPropertyName = "Danhgia";
            this.Danhgia.HeaderText = "Đánh giá";
            this.Danhgia.MinimumWidth = 6;
            this.Danhgia.Name = "Danhgia";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 589);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(246, 29);
            this.label9.TabIndex = 8;
            this.label9.Text = "Đánh giá trung bình:";
            // 
            // ptb_fstar1
            // 
            this.ptb_fstar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_fstar1.BackgroundImage")));
            this.ptb_fstar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_fstar1.Location = new System.Drawing.Point(258, 577);
            this.ptb_fstar1.Name = "ptb_fstar1";
            this.ptb_fstar1.Size = new System.Drawing.Size(47, 41);
            this.ptb_fstar1.TabIndex = 10;
            this.ptb_fstar1.TabStop = false;
            this.ptb_fstar1.Visible = false;
            // 
            // ptb_fstar2
            // 
            this.ptb_fstar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_fstar2.BackgroundImage")));
            this.ptb_fstar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_fstar2.Location = new System.Drawing.Point(311, 577);
            this.ptb_fstar2.Name = "ptb_fstar2";
            this.ptb_fstar2.Size = new System.Drawing.Size(47, 41);
            this.ptb_fstar2.TabIndex = 10;
            this.ptb_fstar2.TabStop = false;
            this.ptb_fstar2.Visible = false;
            // 
            // ptb_fstar3
            // 
            this.ptb_fstar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_fstar3.BackgroundImage")));
            this.ptb_fstar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_fstar3.Location = new System.Drawing.Point(364, 577);
            this.ptb_fstar3.Name = "ptb_fstar3";
            this.ptb_fstar3.Size = new System.Drawing.Size(47, 41);
            this.ptb_fstar3.TabIndex = 10;
            this.ptb_fstar3.TabStop = false;
            this.ptb_fstar3.Visible = false;
            // 
            // ptb_fstar4
            // 
            this.ptb_fstar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_fstar4.BackgroundImage")));
            this.ptb_fstar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_fstar4.Location = new System.Drawing.Point(415, 577);
            this.ptb_fstar4.Name = "ptb_fstar4";
            this.ptb_fstar4.Size = new System.Drawing.Size(47, 41);
            this.ptb_fstar4.TabIndex = 10;
            this.ptb_fstar4.TabStop = false;
            this.ptb_fstar4.Visible = false;
            // 
            // ptb_fstar5
            // 
            this.ptb_fstar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_fstar5.BackgroundImage")));
            this.ptb_fstar5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_fstar5.Location = new System.Drawing.Point(468, 577);
            this.ptb_fstar5.Name = "ptb_fstar5";
            this.ptb_fstar5.Size = new System.Drawing.Size(47, 41);
            this.ptb_fstar5.TabIndex = 10;
            this.ptb_fstar5.TabStop = false;
            this.ptb_fstar5.Visible = false;
            // 
            // ptb_hstar5
            // 
            this.ptb_hstar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_hstar5.BackgroundImage")));
            this.ptb_hstar5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_hstar5.Location = new System.Drawing.Point(468, 577);
            this.ptb_hstar5.Name = "ptb_hstar5";
            this.ptb_hstar5.Size = new System.Drawing.Size(47, 41);
            this.ptb_hstar5.TabIndex = 11;
            this.ptb_hstar5.TabStop = false;
            this.ptb_hstar5.Visible = false;
            // 
            // ptb_hstar4
            // 
            this.ptb_hstar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_hstar4.BackgroundImage")));
            this.ptb_hstar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_hstar4.Location = new System.Drawing.Point(415, 577);
            this.ptb_hstar4.Name = "ptb_hstar4";
            this.ptb_hstar4.Size = new System.Drawing.Size(47, 41);
            this.ptb_hstar4.TabIndex = 12;
            this.ptb_hstar4.TabStop = false;
            this.ptb_hstar4.Visible = false;
            // 
            // ptb_hstar3
            // 
            this.ptb_hstar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_hstar3.BackgroundImage")));
            this.ptb_hstar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_hstar3.Location = new System.Drawing.Point(364, 577);
            this.ptb_hstar3.Name = "ptb_hstar3";
            this.ptb_hstar3.Size = new System.Drawing.Size(47, 41);
            this.ptb_hstar3.TabIndex = 13;
            this.ptb_hstar3.TabStop = false;
            this.ptb_hstar3.Visible = false;
            // 
            // ptb_hstar2
            // 
            this.ptb_hstar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_hstar2.BackgroundImage")));
            this.ptb_hstar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_hstar2.Location = new System.Drawing.Point(311, 577);
            this.ptb_hstar2.Name = "ptb_hstar2";
            this.ptb_hstar2.Size = new System.Drawing.Size(47, 41);
            this.ptb_hstar2.TabIndex = 14;
            this.ptb_hstar2.TabStop = false;
            this.ptb_hstar2.Visible = false;
            // 
            // ptb_hstar1
            // 
            this.ptb_hstar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptb_hstar1.BackgroundImage")));
            this.ptb_hstar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptb_hstar1.Location = new System.Drawing.Point(258, 577);
            this.ptb_hstar1.Name = "ptb_hstar1";
            this.ptb_hstar1.Size = new System.Drawing.Size(47, 41);
            this.ptb_hstar1.TabIndex = 15;
            this.ptb_hstar1.TabStop = false;
            this.ptb_hstar1.Visible = false;
            // 
            // lb_review
            // 
            this.lb_review.AutoSize = true;
            this.lb_review.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_review.ForeColor = System.Drawing.Color.Gold;
            this.lb_review.Location = new System.Drawing.Point(253, 592);
            this.lb_review.Name = "lb_review";
            this.lb_review.Size = new System.Drawing.Size(99, 29);
            this.lb_review.TabIndex = 16;
            this.lb_review.Text = "label10";
            this.lb_review.Visible = false;
            // 
            // form_phone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1249, 817);
            this.Controls.Add(this.lb_review);
            this.Controls.Add(this.ptb_hstar5);
            this.Controls.Add(this.ptb_hstar4);
            this.Controls.Add(this.ptb_hstar3);
            this.Controls.Add(this.ptb_hstar2);
            this.Controls.Add(this.ptb_hstar1);
            this.Controls.Add(this.ptb_fstar5);
            this.Controls.Add(this.ptb_fstar4);
            this.Controls.Add(this.ptb_fstar3);
            this.Controls.Add(this.ptb_fstar2);
            this.Controls.Add(this.ptb_fstar1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dt_cmts);
            this.Controls.Add(this.num_sl);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.lb_gia);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pt_phone);
            this.Controls.Add(this.lb_pin);
            this.Controls.Add(this.lb_rom);
            this.Controls.Add(this.lb_ram);
            this.Controls.Add(this.lb_chip);
            this.Controls.Add(this.lb_selfie);
            this.Controls.Add(this.lb_camera);
            this.Controls.Add(this.lb_os);
            this.Controls.Add(this.lb_screen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "form_phone";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông tin điện thoại";
            this.Load += new System.EventHandler(this.form_phone_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pt_phone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_sl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dt_cmts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_fstar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_hstar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_screen;
        private System.Windows.Forms.PictureBox pt_phone;
        private System.Windows.Forms.ImageList il_phones;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label lb_os;
        private System.Windows.Forms.Label lb_camera;
        private System.Windows.Forms.Label lb_selfie;
        private System.Windows.Forms.Label lb_chip;
        private System.Windows.Forms.Label lb_ram;
        private System.Windows.Forms.Label lb_rom;
        private System.Windows.Forms.Label lb_pin;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_gia;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.NumericUpDown num_sl;
        private System.Windows.Forms.DataGridView dt_cmts;
        private System.Windows.Forms.DataGridViewTextBoxColumn cmt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Danhgia;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox ptb_fstar1;
        private System.Windows.Forms.PictureBox ptb_fstar2;
        private System.Windows.Forms.PictureBox ptb_fstar3;
        private System.Windows.Forms.PictureBox ptb_fstar4;
        private System.Windows.Forms.PictureBox ptb_fstar5;
        private System.Windows.Forms.PictureBox ptb_hstar5;
        private System.Windows.Forms.PictureBox ptb_hstar4;
        private System.Windows.Forms.PictureBox ptb_hstar3;
        private System.Windows.Forms.PictureBox ptb_hstar2;
        private System.Windows.Forms.PictureBox ptb_hstar1;
        private System.Windows.Forms.Label lb_review;
    }
}