﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Reporting.WinForms;
using System.Globalization;
namespace TH02
{
    public partial class form_bill : Form
    {
        CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
        public string iddh { get; set; }
        public string sdt { get; set; }
        public string dchi { get; set; }
        public string pttt { get; set; }
        public string tggh { get; set; }
        public string voucher { get; set; }
        public string ttt { get; set; }
        public string phantram { get; set; }
        public string phaitra { get; set; }
        public form_bill()
        {
            InitializeComponent();
        }

        private void form_bill_Load(object sender, EventArgs e)
       
        {
            DataTable dt = cart_chitiet.get(iddh);
            dt.TableName = "DataTable1";
            string ntn = DateTime.Now.ToString("f", cul);
            string ttt = cart_chitiet.gettongtien(iddh).ToString("C", cul);

            ReportParameter[] paras = new ReportParameter[]
            {
                new ReportParameter("ntn", ntn),
                new ReportParameter("iddh", iddh),
                new ReportParameter("sdt", sdt),
                new ReportParameter("dchi", dchi),
                new ReportParameter("pttt", pttt),
                new ReportParameter("tggh", tggh),
                new ReportParameter("voucher", voucher),
            new ReportParameter("phantram", phantram),
                new ReportParameter("ttt", ttt),
                new ReportParameter("phaitra", phaitra),

            };
            ReportDataSource rds = new ReportDataSource("DataSet1", dt);
            reportViewer1.LocalReport.DataSources.Add(rds); 
            reportViewer1.LocalReport.SetParameters(paras);
            this.reportViewer1.RefreshReport();
        }
    }
}
