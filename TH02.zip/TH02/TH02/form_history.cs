﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QRCoder;
using AForge.Video;
using AForge.Video.DirectShow;
using ZXing;
namespace TH02
{
    public partial class form_history : Form
    {
        List<Tuple<QRCode, string>> list = new List<Tuple<QRCode, string>>();
        bool flag = false;
        DataTable dt = cart.get();
        FilterInfoCollection filterInfoCollection;
        VideoCaptureDevice videoCaptureDevice;
        public form_history()
        {
            InitializeComponent();
        }

        private void form_history_Load(object sender, EventArgs e)
        {
            filterInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo f in filterInfoCollection)
                cb_camera.Items.Add(f.Name);

            dt_ls.DataSource = dt;
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            for (int i = 0; i < dt_ls.Rows.Count; i++)
            {
                QRCode qrcode = new QRCode(qrGenerator.CreateQrCode(dt.Rows[i]["IDDH"].ToString(), QRCodeGenerator.ECCLevel.Q));
                var t = Tuple.Create(qrcode, dt.Rows[i]["IDDH"].ToString());
                list.Add(t);
            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {




        }

        private void btn_qr_Click(object sender, EventArgs e)
        {
            videoCaptureDevice = new VideoCaptureDevice(filterInfoCollection[cb_camera.SelectedIndex].MonikerString);
            videoCaptureDevice.NewFrame += VideoCaptureDevice_NewFrame;
            videoCaptureDevice.Start();
            timer1.Start();
            flag = true;
        }

        private void VideoCaptureDevice_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pictureBox1.Image = (Bitmap)eventArgs.Frame.Clone();
        }

        private void form_history_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (flag == true)
            {
                if (videoCaptureDevice.IsRunning)
                    videoCaptureDevice.Stop();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                BarcodeReader b = new BarcodeReader();
                Result r = b.Decode((Bitmap)pictureBox1.Image);


                if (r != null)
                {
                    txt_search.Text = r.ToString();

                    MessageBox.Show("Quét mã thành công!");
                    timer1.Stop();
                    if (videoCaptureDevice.IsRunning)
                        videoCaptureDevice.Stop();
                }


            }
        }

        private void btn_save_Click_1(object sender, EventArgs e)
        {
            for (int i = 0; i < list.Count; i++)
            {
                Image qrimg = list[i].Item1.GetGraphic(2, Color.Black, Color.White, false);

                string name = list[i].Item2;
                qrimg.Save(String.Format("..\\..\\..\\QRCodes\\{0}.png", name), ImageFormat.Png);
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            dt = cart.get();
            if (!String.IsNullOrEmpty(txt_search.Text))
            {
                string namep = txt_search.Text;
                string query = string.Format("IDDH like'%{0}%'", namep);
                DataRow[] result = dt.Select(query);
                if (result.Length > 0)
                    dt = result.CopyToDataTable();
                else
                    dt.Clear();
                dt_ls.DataSource = dt;
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txt_search_MouseClick(object sender, MouseEventArgs e)
        {
            txt_search.Text = "";
            txt_search.ForeColor = Color.Black;
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {
                
                int irow = dt_ls.CurrentCell.RowIndex;
                string tinhtrang = dt_ls.Rows[irow].Cells["Tinhtrang"].Value.ToString();
                if (tinhtrang != "Đang giao")
                {
                    string iddh = dt_ls.Rows[irow].Cells[0].Value.ToString();
                    string dt = DateTime.Now.ToString();
                    cart.UpdateTinhtrang(iddh, "Đã hủy " + dt);
                   
                }
                else
                    MessageBox.Show("Đơn hàng chưa giao/đã hủy/đã đổi không thể đổi trả!");

            }
            dt = cart.get();
            dt_ls.DataSource = dt;
        }

        private void btn_refund_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {

                int irow = dt_ls.CurrentCell.RowIndex;
                string tinhtrang = dt_ls.Rows[irow].Cells["Tinhtrang"].Value.ToString();
                if (tinhtrang != "Đã giao")
                
                {
                    string iddh = dt_ls.Rows[irow].Cells[0].Value.ToString();
                    string dt = DateTime.Now.ToString();
                    cart.UpdateTinhtrang(iddh, "Đổi trả " + dt);

                }
                else
                    MessageBox.Show("Đơn hàng chưa giao/đã hủy/đã đổi không thể đổi trả!");


            }
            dt = cart.get();
            dt_ls.DataSource = dt;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {

                int irow = dt_ls.CurrentCell.RowIndex;
              
                    string iddh = dt_ls.Rows[irow].Cells[0].Value.ToString();
                form_detail f = new form_detail();
                f.iddh = iddh;
                f.ShowDialog();
             

                

            }
        }

        private void btn_danhgia_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {

                int irow = dt_ls.CurrentCell.RowIndex;

                string iddh = dt_ls.Rows[irow].Cells[0].Value.ToString();
                form_review rv = new form_review();
                rv.iddh = iddh;
                rv.ShowDialog();
            }
                
            
        }
    }
}
