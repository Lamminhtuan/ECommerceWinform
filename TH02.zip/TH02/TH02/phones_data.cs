﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace TH02
{
    internal class phones_data
    {
        private static DataTable dt;
        public static DataTable Khoitao()
        {
            dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("DT", typeof(string));
            dt.Columns.Add("Hang", typeof(string));
            dt.Columns.Add("Gia", typeof(decimal));
            dt.Columns.Add("Screen", typeof(string));
            dt.Columns.Add("OS", typeof(string));
            dt.Columns.Add("Camera", typeof(string));
            dt.Columns.Add("Selfie", typeof(string));
            dt.Columns.Add("Chip", typeof(string));
            dt.Columns.Add("RAM", typeof(int));
            dt.Columns.Add("ROM", typeof(int));
            dt.Columns.Add("Pin", typeof(string));
            dt.Rows.Add(0, "iPhone 14 Pro Max 128 GB", "Apple", 33990000, "OLED 6.7\" Super Retina XDR", "iOS", "Chính 48 MP & Phụ 12 MP, 12 MP", "12 MP", "Apple A16 Bionic", 6, 128, "4323 mAh");
            dt.Rows.Add(1, "iPhone 14 Pro", "Apple", 30590000, "OLED 6.1\" Super Retina XDR",  "iOS", "Chính 48 MP & Phụ 12 MP, 12 MP","12 MP", "Apple A16 Bionic", 6, 128, "3200 mAh");
            
            dt.Rows.Add(2, "iPhone 13 Pro Max", "Apple", 28490000, "OLED 6.7\" Super Retina XDR", "iOS", "3 camera 12 MP ", "12 MP", "Apple 15 Bionic", 6, 128, "4352 mAh ");
            dt.Rows.Add(3, "Samsung Galaxy S22 Ultra", "Samsung", 25990000, "Dynamic AMOLED 2X 6.8 Quad HD + (2K +)", "Android", "Chính 108 MP & Phụ 12 MP, 10 MP, 10 MP", "40 MP", "Snapdragon 8 Gen 1",  8, 128, "5000 mAh");
            dt.Rows.Add(4, "Samsung Galaxy S22+", "Samsung", 21990000, "Dynamic AMOLED 2X 6.6\" Full HD + ", "Android", "Chính 50 MP & Phụ 12 MP, 10 MP", "10 MP","Snapdragon 8 Gen 1 ", 8, 128, "4500 mAh");
            dt.Rows.Add(5, "Samsung Galaxy Z Fold4 5G", "Samsung", 37990000, "Dynamic AMOLED 2X Chính 7.6\" & Phụ 6.2\" Quad HD+ (2K+)" , "Android", "Chính 50 MP & Phụ 12 MP, 10 MP ", "10 MP & 4 MP ", "Snapdragon 8+ Gen 1", 12, 256, "4400 mAh");
            dt.Rows.Add(6, "Samsung Galaxy Z Flip4 5G", "Samsung", 20990000, " Chính: Dynamic AMOLED 2X, Phụ: Super AMOLED Chính 6.7\" & Phụ 1.9\" Full HD+ ", "Android", "2 camera 12 MP", " 10 MP ", " Snapdragon 8+ Gen 1 ", 8, 256, "3700 mAh");
            dt.Rows.Add(7, "OPPO Find X5 Pro 5G", "OPPO", 30490000, "AMOLED 6.7\" Quad HD + (2K +) ", "Android", "Chính 50 MP & Phụ 50 MP, 13 MP ", "32 MP", "Snapdragon 8 Gen 1", 12, 256, "5000 mAh");
            dt.Rows.Add(8, "Xiaomi 12 Pro", "Xiaomi", 25490000, "AMOLED 6.73\" Quad HD + (2K +) ","Android", "3 camera 50 MP","32 MP", "Snapdragon 8 Gen 1 ", 12, 256, "4600 mAh");
            dt.Rows.Add(9, "Vivo X80", "Vivo", 19190000, "AMOLED 6.78\" Full HD + ", "Android", "Chính 50 MP & Phụ 12 MP, 12 MP ", "32 MP ", "MediaTek Dimensity 9000 ", 12, 256, "4500 mAh");
            dt.Rows.Add(10, "OPPO Reno8 Pro 5G", "OPPO", 18990000, "AMOLED 6.7\" Full HD +", "Android", "Chính 50 MP & Phụ 8 MP, 2 MP ", "32 MP", "MediaTek Dimensity 8100 Max 8 nhân ", 12, 256, "4500 mAh");
            dt.Rows.Add(11, "Samsung Galaxy S21 FE 5G", "Samsung", 12990000, "Dynamic AMOLED 2X 6.4\" Full HD +", "Android", "Chính 12 MP & Phụ 12 MP, 8 MP ", "32 MP", "Exynos 2100 ", 8, 128, "4500 mAh");
            dt.Rows.Add(12, "Samsung Galaxy A73 5G", "Samsung", 11990000, "Super AMOLED Plus 6.7\" Full HD + ","Android", "Chính 108 MP & Phụ 12 MP, 5 MP, 5 MP ", "32 MP", "Snapdragon 778G 5G ", 8, 128, "5000 mAh");
            dt.Rows.Add(13, "Vivo V23 5G", "Vivo", 11690000, "AMOLED 6.44\" Full HD + ", "Android", "Chính 64 MP & Phụ 8 MP, 2 MP ", "Chính 50 MP & Phụ 8 MP ", "MediaTek Dimensity 920 5G ", 8, 128, "4200 mAh");
            dt.Rows.Add(14, "Xiaomi 12T 5G", "Xiaomi", 12490000, "AMOLED 6.67\" 1.5K ","Android", "Chính 108 MP & Phụ 8 MP, 2 MP ","20 MP", "MediaTek Dimensity 8100 Ultra 8 nhân ", 8, 128, "5000 mAh");
            dt.Rows.Add(15, "iPhone SE (2022)", "Apple", 12990000, "IPS LCD 4.7\" Retina HD ","iOS", "12 MP","7 MP", "Apple A15 Bionic ", 4, 128, "2018 mAh");
            dt.Rows.Add(16, "Realme 9 Pro+ 5G", "Realme", 9990000, "Super AMOLED 6.4\" Full HD + ", "Android", "Chính 50 MP & Phụ 8 MP, 2 MP ", "16 MP", "MediaTek Dimensity 920 5G ", 8, 128, "4500 mAh");
            dt.Rows.Add(17, "Samsung Galaxy A53 5G", "Samsung", 9990000, "Super AMOLED 6.5\" Full HD + ", "Android", "Chính 64 MP & Phụ 12 MP, 5 MP, 5 MP ","32 MP", "Exynos 1280", 8, 128, "5000 mAh");
            dt.Rows.Add(18, "Xiaomi Redmi Note 10 Pro", "Xiaomi", 7090000, "AMOLED 6.67\" Full HD + ", "Android", "Chính 108 MP & Phụ 8 MP, 5 MP, 2 MP ","16 MP", "Snapdragon 732G ", 8, 128, "5020 mAh");
            dt.Rows.Add(19, "Vivo V23e", "Vivo", 7190000, "AMOLED 6.44\" Full HD + ", "Android", "Chính 64 MP & Phụ 8 MP, 2 MP ","50 MP", "MediaTek Helio G96 ", 8, 128, "4050 mAh");
            dt.Rows.Add(20, "Xiaomi Redmi Note 11 Pro", "Xiaomi", 7190000, "AMOLED 6.67\" Full HD + ", "Android", "Chính 108 MP & Phụ 8 MP, 2 MP, 2 MP ", "16 MP", "MediaTek Helio G96 ", 8, 128, "5000 mAh");
            dt.Rows.Add(21, "Samsung Galaxy A33 5G", "Samsung", 7290000, "Super AMOLED 6.4\" Full HD + ","Android", "Chính 48 MP & Phụ 8 MP, 5 MP, 2 MP ","13 MP", "Exynos 1280 ", 6, 128, "5000 mAh");
            dt.Rows.Add(22, "Vivo T1 5G", "Vivo", 7990000, "AMOLED 6.44\" Full HD + ","Android", "Chính 64 MP & Phụ 8 MP, 2 MP ","16 MP", "Snapdragon 778G 5G ", 8, 128, "4700 mAh");
            dt.Rows.Add(23, "Vivo Y53S", "Vivo", 6990000, "IPS LCD 6.58\" Full HD + ","Android", "Chính 64 MP & Phụ 2 MP, 2 MP ", "16 MP", "MediaTek Helio G80 ", 8, 128, "5000 mAh");
            dt.Rows.Add(24, "OPPO A96", "Oppo", 6490000, "IPS LCD 6.59\" Full HD + ","Android", "Chính 50 MP & Phụ 2 MP ","16 MP", "Snapdragon 680 ", 8, 128, "5000 mAh");
            dt.Rows.Add(25, "Realme C21-Y", "Realme", 2690000, "IPS LCD 6.5\" HD + ", "Android", "Chính 13 MP & Phụ 2 MP, 2 MP ","5 MP", "Spreadtrum T610 ", 3, 32, "5000 mAh");
            dt.Rows.Add(26, "Realme C11", "Realme", 2790000, "IPS LCD 6.5\" HD + ","Android", "8 MP","5 MP", "Spreadtrum SC9863A ", 4, 64, "5000 mAh");
            dt.Rows.Add(27, "Nokia C31", "Nokia", 2790000, "TFT LCD 6.7\" HD + ", "Android", "Chính 13 MP & Phụ 2 MP, 2 MP ","5 MP", "Unisoc SC9863A1 ", 3, 32, "5050 mAh");
            dt.Rows.Add(28, "Nokia G10", "Nokia", 2990000, "TFT LCD 6.5\" HD + ","Android", "Chính 13 MP & Phụ 2 MP, 2 MP ","8 MP", "MediaTek Helio G25 ", 4, 64, "5050 mAh");
            dt.Rows.Add(29, "Nokia G21", "Nokia", 3890000, "TFT LCD 6.5\" HD + ","Android", "Chính 50 MP & Phụ 2 MP, 2 MP ","8 MP", "Unisoc T606 ", 4, 128, "5050 mAh");
            dt.Rows.Add(30, "iPhone 14 Pro Max 1TB", "Apple", 49990000, "OLED 6.7\" Super Retina XDR", "iOS", "Chính 48 MP & Phụ 12 MP, 12 MP", "12 MP", "Apple A16 Bionic", 6, 1024, "4323 mAh");
            dt.Rows.Add(31, "Xiaomi Redmi 10A", "Xiaomi", 2490000, "IPS LCD 6.53\" HD + ", "Android", "Chính 13 MP & Phụ 2 MP ", "5 MP", "MediaTek Helio G25 ", 2, 32, "5000 mAh");
            dt.Rows.Add(32, "Xiaomi Redmi 9A", "Xiaomi", 2290000, "IPS LCD 6.53\" HD + ", "Android", "13 MP", "5 MP", "MediaTek Helio G25 ", 2, 32, "5000 mAh");
            dt.Rows.Add(33, "Xiaomi 11T Pro 5G", "Xiaomi", 14390000, "AMOLED 6.67\" Full HD + ", "Android", "Chính 108 MP & Phụ 8 MP, 5 MP ", "16 MP", "Snapdragon 888 ", 12, 256, "5000 mAh");
            dt.Rows.Add(34, "Samsung Galaxy S22 Ultra 512 GB", "Samsung", 29990000, "Dynamic AMOLED 2X 6.8 Quad HD + (2K +)", "Android", "Chính 108 MP & Phụ 12 MP, 10 MP, 10 MP", "40 MP", "Snapdragon 8 Gen 1", 12, 512, "5000 mAh");
            dt.Rows.Add(35, "Samsung Galaxy M53", "Samsung", 11990000, " Super AMOLED Plus 6.7\" Full HD + ", "Android", "Chính 108 MP & Phụ 8 MP, 2 MP, 2 MP", "32 MP", "MediaTek Dimensity 900 5G ", 8, 256, "5000 mAh");
            dt.Rows.Add(36, "Xiaomi 11 Lite 5G NE", "Xiaomi", 8490000, "AMOLED 6.55\" Full HD + ", "Android", "Chính 64 MP & Phụ 8 MP, 5 MP ", "20 MP", "Snapdragon 778G 5G" , 8, 128, "4250 mAh");
            dt.Rows.Add(37, "Xiaomi Redmi 9C", "Xiaomi", 3290000, "IPS LCD 6.53\" HD + ", "Android", "Chính 13 MP & Phụ 2 MP, 2 MP ", "5 MP", "MediaTek Helio G35 ", 4, 128, "5000 mAh");
            dt.Rows.Add(38, "iPhone 14 256 GB", "Apple", 24990000, "OLED 6.1\" Super Retina XDR", "iOS", "2 camera 12 MP ", "12 MP", "Apple A15 Bionic", 6, 256, "3279 mAh");
            dt.Rows.Add(39, "iPhone 14 Plus 256 GB", "Apple", 27990000, "OLED 6.7\" Super Retina XDR", "iOS", "2 camera 12 MP ", "12 MP", "Apple A15 Bionic", 6, 256, "4325 mAh");
            dt.Rows.Add(40, "Samsung Galaxy Z Fold3 5G", "Samsung", 31990000, "Dynamic AMOLED 2X Chính 7.6\" & Phụ 6.2\" Full HD+", "Android", "3 camera 12 MP ", "10 MP & 4 MP ", "Snapdragon 888", 12, 512, "4400 mAh");
            dt.Rows.Add(41, "iPhone 13 mini 512 GB", "Apple", 22490000, "OLED 5.4\" Super Retina XDR", "iOS", "2 camera 12 MP ", "12 MP", "Apple A15 Bionic", 4, 512, "2438 mAh");
            dt.Rows.Add(42, "iPhone 13 512 GB", "Apple", 25990000, "OLED 6.1\" Super Retina XDR", "iOS", "2 camera 12 MP ", "12 MP", "Apple A15 Bionic", 4, 512, "3240 mAh");
            dt.Rows.Add(43, "OPPO A17", "Oppo", 3790000, "IPS LCD 6.56\" HD + ", "Android", "Chính 50 MP & Phụ 0.3 MP ", "5 MP", "MediaTek Helio G35 ", 4, 64, "5000 mAh");
            dt.Rows.Add(44, "Samsung Galaxy A04 ", "Samsung", 2790000, " IPS LCD 6.5\" HD + ", "Android", "Chính 50 MP & Phụ 2 MP ", "5 MP", "MediaTek Helio P35 ", 3, 32, "5000 mAh");
            dt.Rows.Add(45, "Realme C33", "Realme", 3690000, "IPS LCD 6.5\" HD + ", "Android", "Chính 50 MP & Phụ 0.3 MP ", "5 MP", "Unisoc Tiger T612 ", 4, 64, "5000 mAh");
            dt.Rows.Add(46, "Realme C30s", "Realme", 2990000, "IPS LCD 6.5\" HD + ", "Android", "8 MP", "5 MP", "Unisoc SC9863A1", 4, 64, "5000 mAh");
            dt.Rows.Add(47, "Nokia G11 Plus", "Nokia", 3140000, "TFT LCD 6.51\" HD + ", "Android", "Chính 50 MP & Phụ 2 MP", "8 MP", "Unisoc T606 ", 3, 64, "5050 mAh");
            dt.Rows.Add(48, "Vivo Y16", "Vivo", 3790000, "IPS LCD 6.51\" HD + ", "Android", "Chính 13 MP & Phụ 2 MP", "5 MP", "MediaTek Helio P35 ", 4, 64, "5000 mAh");
            dt.Rows.Add(49, "Nokia C21 Plus", "Nokia", 2790000, "TFT LCD 6.5\" HD + ", "Android", "Chính 13 MP & Phụ 2 MP", "5 MP", "Spreadtrum SC9863A ", 3, 64, "5050 mAh");
            return dt;
        }
        public static DataRow[] GetPhone(int id)
        {
            DataRow[] dr = dt.Select(string.Format("ID={0}", id));
            return dr;
        }
    

    }
}
