﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace TH02
{
    internal class voucher
    {
        private static DataTable dt;
        public static void Khoitao()
        {
            dt = new DataTable();
            dt.Columns.Add("Voucher", typeof(string));
            dt.Columns.Add("Phantram", typeof(decimal));
            dt.Rows.Add("TUAN1", 0.1);
            dt.Rows.Add("TUAN2", 0.2);
            dt.Rows.Add("TUAN3", 0.3);

        }
        public static decimal GiamGia(string voucher)
        {
            decimal r = 0;
            DataRow[] dr = dt.Select(string.Format("Voucher = '{0}'", voucher));
            if (dr.Length > 0)
               
                r = Convert.ToDecimal(dr[0]["Phantram"].ToString());
            return r;
        }
    }
}
