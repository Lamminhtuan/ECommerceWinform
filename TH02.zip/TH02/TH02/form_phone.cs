﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class form_phone : Form
    {

        public string name { get; set; }
        public decimal gia { get; set; }
        public string screen { get; set; }
        public int id { get; set; }
        public string os { get; set; }
        public string camera { get; set; }
        public string selfie { get; set; }
        public string chip { get; set; }
        public string ram { get; set; }
        public string rom { get; set; }
        public string pin { get; set; }
        public form_phone()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void form_phone_Load(object sender, EventArgs e)
        {
            lb_name.Text = name;
            CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
            string giaa = String.Format(cul, "{0:c}", gia);

            lb_gia.Text = giaa;
            lb_screen.Text = screen;
            lb_os.Text = os;

            lb_camera.Text = camera;
            lb_selfie.Text = selfie;
            lb_chip.Text = chip;
            lb_ram.Text = ram;
            lb_rom.Text = rom;
            lb_pin.Text = pin;
            pt_phone.Image = il_phones.Images[id];
            DataTable dts = comments.GetCmts(id);
            if (dts.Rows.Count > 0)
            {
                dts.Columns.Remove("ID");
                dt_cmts.DataSource = dts;
            }
            decimal avg = comments.GetAvg(id);
            if (avg == -1)
            {
                lb_review.Text = "Chưa có đánh giá";
                lb_review.Visible = true;

            }
            else
            {
                if (avg == 0.5m)
                {
                    ptb_hstar1.Visible = true;
                }
                else if (avg == 1)
                {
                    ptb_fstar1.Visible = true;
                }
                else if (avg == 1.5m)
                {
                    ptb_fstar1.Visible = true;
                    ptb_hstar2.Visible = true;
                }
                else if (avg == 2)
                {
                    ptb_fstar1.Visible = true;
                    ptb_fstar2.Visible = true;

                }
                else if (avg == 2.5m)
                {
                    ptb_fstar1.Visible = true;
                    ptb_fstar2.Visible = true;
                    ptb_hstar3.Visible = true;
                }
                else if (avg == 3)
                {
                    ptb_fstar1.Visible = true;
                    ptb_fstar2.Visible = true;
                    ptb_fstar3.Visible = true;
                }
                else if (avg == 3.5m)
                {
                    ptb_fstar1.Visible = true;
                    ptb_fstar2.Visible = true;
                    ptb_fstar3.Visible = true;
                    ptb_hstar4.Visible = true;
                }
                else if (avg == 4)
                {
                    ptb_fstar1.Visible = true;
                    ptb_fstar2.Visible = true;
                    ptb_fstar3.Visible = true;
                    ptb_fstar4.Visible = true;
                }
                else if (avg == 4.5m)
                {
                    ptb_fstar1.Visible = true;
                    ptb_fstar2.Visible = true;
                    ptb_fstar3.Visible = true;
                    ptb_fstar4.Visible = true;
                    ptb_hstar5.Visible = true;
                }
                else if (avg == 5)
                {
                    ptb_fstar1.Visible = true;
                    ptb_fstar2.Visible = true;
                    ptb_fstar3.Visible = true;
                    ptb_fstar4.Visible = true;
                    ptb_fstar5.Visible = true;
                }

            }
        }

        private void pt_phone_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            int sl = Convert.ToInt32(num_sl.Value.ToString());
            decimal gia_a = Convert.ToDecimal(gia);
            string iddh = cart.GetID();

            cart_chitiet.Add(iddh, id, name, gia_a, sl);
            MessageBox.Show("Thêm vào giỏ hàng thành công!");
        }

        private void dt_cmts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
