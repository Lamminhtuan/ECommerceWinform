﻿namespace TH02
{
    partial class form_history
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_history));
            this.dt_ls = new System.Windows.Forms.DataGridView();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_camera = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_qr = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_refund = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_danhgia = new System.Windows.Forms.Button();
            this.IDDH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tongtien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phantram = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phaitra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Voucher = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Diachi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ngay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PTTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SDT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tinhtrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dt_ls)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // dt_ls
            // 
            this.dt_ls.AllowUserToAddRows = false;
            this.dt_ls.AllowUserToDeleteRows = false;
            this.dt_ls.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dt_ls.BackgroundColor = System.Drawing.Color.White;
            this.dt_ls.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dt_ls.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDDH,
            this.Tongtien,
            this.Phantram,
            this.Phaitra,
            this.Voucher,
            this.Diachi,
            this.Ngay,
            this.PTTT,
            this.SDT,
            this.Tinhtrang});
            this.dt_ls.Location = new System.Drawing.Point(12, 58);
            this.dt_ls.Name = "dt_ls";
            this.dt_ls.RowHeadersWidth = 51;
            this.dt_ls.RowTemplate.Height = 24;
            this.dt_ls.Size = new System.Drawing.Size(1116, 338);
            this.dt_ls.TabIndex = 0;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_delete.FlatAppearance.BorderSize = 0;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_delete.Image")));
            this.btn_delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_delete.Location = new System.Drawing.Point(678, 400);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(198, 38);
            this.btn_delete.TabIndex = 5;
            this.btn_delete.Text = "Xem chi tiết";
            this.btn_delete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_search.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_search.BackgroundImage")));
            this.btn_search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_search.FlatAppearance.BorderSize = 0;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.Location = new System.Drawing.Point(740, 9);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(52, 38);
            this.btn_search.TabIndex = 7;
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txt_search
            // 
            this.txt_search.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_search.Location = new System.Drawing.Point(333, 9);
            this.txt_search.Multiline = true;
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(401, 38);
            this.txt_search.TabIndex = 6;
            this.txt_search.Text = "Tìm kiếm mã đơn hàng";
            this.txt_search.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txt_search_MouseClick);
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.White;
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_save.Location = new System.Drawing.Point(474, 400);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(198, 38);
            this.btn_save.TabIndex = 5;
            this.btn_save.Text = "Lưu tất cả mã QR";
            this.btn_save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Magenta;
            this.label1.Location = new System.Drawing.Point(1143, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 29);
            this.label1.TabIndex = 8;
            this.label1.Text = "Camera:";
            // 
            // cb_camera
            // 
            this.cb_camera.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_camera.FormattingEnabled = true;
            this.cb_camera.Location = new System.Drawing.Point(1253, 13);
            this.cb_camera.Name = "cb_camera";
            this.cb_camera.Size = new System.Drawing.Size(121, 33);
            this.cb_camera.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(1134, 58);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(444, 381);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // btn_qr
            // 
            this.btn_qr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_qr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_qr.FlatAppearance.BorderSize = 0;
            this.btn_qr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_qr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_qr.ForeColor = System.Drawing.Color.White;
            this.btn_qr.Image = ((System.Drawing.Image)(resources.GetObject("btn_qr.Image")));
            this.btn_qr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_qr.Location = new System.Drawing.Point(1380, 13);
            this.btn_qr.Name = "btn_qr";
            this.btn_qr.Size = new System.Drawing.Size(198, 34);
            this.btn_qr.TabIndex = 5;
            this.btn_qr.Text = "Lấy mã QR";
            this.btn_qr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_qr.UseVisualStyleBackColor = false;
            this.btn_qr.Click += new System.EventHandler(this.btn_qr_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_cancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cancel.FlatAppearance.BorderSize = 0;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.ForeColor = System.Drawing.Color.White;
            this.btn_cancel.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel.Image")));
            this.btn_cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_cancel.Location = new System.Drawing.Point(270, 400);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(198, 38);
            this.btn_cancel.TabIndex = 5;
            this.btn_cancel.Text = "Hủy đơn";
            this.btn_cancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_refund
            // 
            this.btn_refund.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_refund.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_refund.FlatAppearance.BorderSize = 0;
            this.btn_refund.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_refund.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refund.ForeColor = System.Drawing.Color.White;
            this.btn_refund.Image = ((System.Drawing.Image)(resources.GetObject("btn_refund.Image")));
            this.btn_refund.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_refund.Location = new System.Drawing.Point(66, 402);
            this.btn_refund.Name = "btn_refund";
            this.btn_refund.Size = new System.Drawing.Size(198, 38);
            this.btn_refund.TabIndex = 5;
            this.btn_refund.Text = "Đổi trả";
            this.btn_refund.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_refund.UseVisualStyleBackColor = false;
            this.btn_refund.Click += new System.EventHandler(this.btn_refund_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(1099, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(38, 30);
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // btn_danhgia
            // 
            this.btn_danhgia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_danhgia.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_danhgia.FlatAppearance.BorderSize = 0;
            this.btn_danhgia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_danhgia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_danhgia.ForeColor = System.Drawing.Color.White;
            this.btn_danhgia.Image = ((System.Drawing.Image)(resources.GetObject("btn_danhgia.Image")));
            this.btn_danhgia.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_danhgia.Location = new System.Drawing.Point(882, 400);
            this.btn_danhgia.Name = "btn_danhgia";
            this.btn_danhgia.Size = new System.Drawing.Size(198, 38);
            this.btn_danhgia.TabIndex = 5;
            this.btn_danhgia.Text = "Đánh giá";
            this.btn_danhgia.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_danhgia.UseVisualStyleBackColor = false;
            this.btn_danhgia.Click += new System.EventHandler(this.btn_danhgia_Click);
            // 
            // IDDH
            // 
            this.IDDH.DataPropertyName = "IDDH";
            this.IDDH.HeaderText = "Mã đơn hàng";
            this.IDDH.MinimumWidth = 6;
            this.IDDH.Name = "IDDH";
            this.IDDH.ReadOnly = true;
            // 
            // Tongtien
            // 
            this.Tongtien.DataPropertyName = "Tongtien";
            this.Tongtien.HeaderText = "Tổng tiền";
            this.Tongtien.MinimumWidth = 6;
            this.Tongtien.Name = "Tongtien";
            this.Tongtien.ReadOnly = true;
            // 
            // Phantram
            // 
            this.Phantram.DataPropertyName = "Phantram";
            this.Phantram.HeaderText = "Giảm giá";
            this.Phantram.MinimumWidth = 6;
            this.Phantram.Name = "Phantram";
            this.Phantram.ReadOnly = true;
            // 
            // Phaitra
            // 
            this.Phaitra.DataPropertyName = "Phaitra";
            this.Phaitra.HeaderText = "Phải trả";
            this.Phaitra.MinimumWidth = 6;
            this.Phaitra.Name = "Phaitra";
            this.Phaitra.ReadOnly = true;
            // 
            // Voucher
            // 
            this.Voucher.DataPropertyName = "Voucher";
            this.Voucher.HeaderText = "Voucher";
            this.Voucher.MinimumWidth = 6;
            this.Voucher.Name = "Voucher";
            this.Voucher.ReadOnly = true;
            // 
            // Diachi
            // 
            this.Diachi.DataPropertyName = "Diachi";
            this.Diachi.HeaderText = "Địa chỉ giao hàng";
            this.Diachi.MinimumWidth = 6;
            this.Diachi.Name = "Diachi";
            this.Diachi.ReadOnly = true;
            // 
            // Ngay
            // 
            this.Ngay.DataPropertyName = "Thoigiangiaohang";
            this.Ngay.HeaderText = "Thời gian giao hàng";
            this.Ngay.MinimumWidth = 6;
            this.Ngay.Name = "Ngay";
            this.Ngay.ReadOnly = true;
            this.Ngay.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // PTTT
            // 
            this.PTTT.DataPropertyName = "PTTT";
            this.PTTT.HeaderText = "Phương thức thanh toán";
            this.PTTT.MinimumWidth = 6;
            this.PTTT.Name = "PTTT";
            this.PTTT.ReadOnly = true;
            // 
            // SDT
            // 
            this.SDT.DataPropertyName = "DT";
            this.SDT.HeaderText = "SDT";
            this.SDT.MinimumWidth = 6;
            this.SDT.Name = "SDT";
            this.SDT.ReadOnly = true;
            // 
            // Tinhtrang
            // 
            this.Tinhtrang.DataPropertyName = "Tinhtrang";
            this.Tinhtrang.HeaderText = "Tình trạng";
            this.Tinhtrang.MinimumWidth = 6;
            this.Tinhtrang.Name = "Tinhtrang";
            this.Tinhtrang.ReadOnly = true;
            // 
            // form_history
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(193)))), ((int)(((byte)(150)))));
            this.ClientSize = new System.Drawing.Size(1590, 451);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cb_camera);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.btn_refund);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_qr);
            this.Controls.Add(this.btn_danhgia);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.dt_ls);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "form_history";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lịch sử đặt hàng";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.form_history_FormClosing);
            this.Load += new System.EventHandler(this.form_history_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dt_ls)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dt_ls;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_camera;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_qr;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_refund;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btn_danhgia;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDDH;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tongtien;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phantram;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phaitra;
        private System.Windows.Forms.DataGridViewTextBoxColumn Voucher;
        private System.Windows.Forms.DataGridViewTextBoxColumn Diachi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ngay;
        private System.Windows.Forms.DataGridViewTextBoxColumn PTTT;
        private System.Windows.Forms.DataGridViewTextBoxColumn SDT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tinhtrang;
    }
}