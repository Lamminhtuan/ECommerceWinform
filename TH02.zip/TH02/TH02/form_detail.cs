﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class form_detail : Form
    {
        
        
        public string iddh { get; set; }

        public form_detail()
        {
            InitializeComponent();
        }

        private void form_paycs_Load(object sender, EventArgs e)
        {
           
            DataTable dt = cart_chitiet.get(iddh);
            DataRow dr = cart.GetByIDDH(iddh);

            dataGridView1.DataSource = dt;
            txt_dc.Text = dr["Diachi"].ToString();
            txt_dth.Text = dr["DT"].ToString();
            txt_phaitra.Text = dr["Phaitra"].ToString();
            txt_iddh.Text = dr["IDDH"].ToString();
            txt_gg.Text = dr["Phantram"].ToString();
            txt_tt.Text = dr["Tongtien"].ToString();
            txt_tggh.Text = dr["Thoigiangiaohang"].ToString();
            txt_pttt.Text = dr["PTTT"].ToString();
            txt_tinhtr.Text = dr["Tinhtrang"].ToString();
            txt_voucher.Text = dr["Voucher"].ToString();
           
        
            
        }

       
    }
}
