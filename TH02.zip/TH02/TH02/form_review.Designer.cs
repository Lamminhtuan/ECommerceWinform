﻿namespace TH02
{
    partial class form_review
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_review));
            this.dt_cmts = new System.Windows.Forms.DataGridView();
            this.btn_done = new System.Windows.Forms.Button();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Binhluan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Danhgia = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dt_cmts)).BeginInit();
            this.SuspendLayout();
            // 
            // dt_cmts
            // 
            this.dt_cmts.AllowUserToAddRows = false;
            this.dt_cmts.AllowUserToDeleteRows = false;
            this.dt_cmts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dt_cmts.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dt_cmts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dt_cmts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.DT,
            this.Binhluan,
            this.Danhgia});
            this.dt_cmts.GridColor = System.Drawing.SystemColors.Control;
            this.dt_cmts.Location = new System.Drawing.Point(12, 12);
            this.dt_cmts.Name = "dt_cmts";
            this.dt_cmts.RowHeadersWidth = 51;
            this.dt_cmts.RowTemplate.Height = 24;
            this.dt_cmts.Size = new System.Drawing.Size(776, 382);
            this.dt_cmts.TabIndex = 0;
            // 
            // btn_done
            // 
            this.btn_done.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_done.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_done.FlatAppearance.BorderSize = 0;
            this.btn_done.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_done.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_done.ForeColor = System.Drawing.Color.White;
            this.btn_done.Image = ((System.Drawing.Image)(resources.GetObject("btn_done.Image")));
            this.btn_done.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_done.Location = new System.Drawing.Point(301, 400);
            this.btn_done.Name = "btn_done";
            this.btn_done.Size = new System.Drawing.Size(198, 38);
            this.btn_done.TabIndex = 8;
            this.btn_done.Text = "Hoàn thành";
            this.btn_done.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_done.UseVisualStyleBackColor = false;
            this.btn_done.Click += new System.EventHandler(this.btn_done_Click);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "Mã điện thoại";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // DT
            // 
            this.DT.DataPropertyName = "DT";
            this.DT.HeaderText = "Tên điện thoại";
            this.DT.MinimumWidth = 6;
            this.DT.Name = "DT";
            this.DT.ReadOnly = true;
            // 
            // Binhluan
            // 
            this.Binhluan.DataPropertyName = "Binhluan";
            this.Binhluan.HeaderText = "Bình luận";
            this.Binhluan.MinimumWidth = 6;
            this.Binhluan.Name = "Binhluan";
            // 
            // Danhgia
            // 
            this.Danhgia.DataPropertyName = "Danhgia";
            this.Danhgia.HeaderText = "Đánh giá";
            this.Danhgia.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.Danhgia.MinimumWidth = 6;
            this.Danhgia.Name = "Danhgia";
            this.Danhgia.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Danhgia.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // form_review
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(193)))), ((int)(((byte)(150)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_done);
            this.Controls.Add(this.dt_cmts);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_review";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đánh giá";
            this.Load += new System.EventHandler(this.form_review_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dt_cmts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dt_cmts;
        private System.Windows.Forms.Button btn_done;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn DT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Binhluan;
        private System.Windows.Forms.DataGridViewComboBoxColumn Danhgia;
    }
}