﻿
namespace TH02
{
    partial class form_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_home));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_recent = new System.Windows.Forms.Button();
            this.btn_cart = new System.Windows.Forms.Button();
            this.btn_ls = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cb_sort = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_hang = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_gia = new System.Windows.Forms.ComboBox();
            this.cb_rom = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chb_rom = new System.Windows.Forms.CheckBox();
            this.cb_ram = new System.Windows.Forms.ComboBox();
            this.chb_ram = new System.Windows.Forms.CheckBox();
            this.chb_hang = new System.Windows.Forms.CheckBox();
            this.chb_gia = new System.Windows.Forms.CheckBox();
            this.btn_delfil = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.il_phones = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lw_phones = new System.Windows.Forms.ListView();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(193)))), ((int)(((byte)(150)))));
            this.panel1.Controls.Add(this.btn_recent);
            this.panel1.Controls.Add(this.btn_cart);
            this.panel1.Controls.Add(this.btn_ls);
            this.panel1.Controls.Add(this.btn_search);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.txt_search);
            this.panel1.Location = new System.Drawing.Point(217, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1136, 64);
            this.panel1.TabIndex = 0;
            // 
            // btn_recent
            // 
            this.btn_recent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_recent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_recent.FlatAppearance.BorderSize = 0;
            this.btn_recent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_recent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_recent.ForeColor = System.Drawing.Color.White;
            this.btn_recent.Image = ((System.Drawing.Image)(resources.GetObject("btn_recent.Image")));
            this.btn_recent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_recent.Location = new System.Drawing.Point(801, 12);
            this.btn_recent.Name = "btn_recent";
            this.btn_recent.Size = new System.Drawing.Size(151, 38);
            this.btn_recent.TabIndex = 3;
            this.btn_recent.Text = "Vừa xem";
            this.btn_recent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_recent.UseVisualStyleBackColor = false;
            this.btn_recent.Click += new System.EventHandler(this.btn_recent_Click);
            // 
            // btn_cart
            // 
            this.btn_cart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_cart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cart.FlatAppearance.BorderSize = 0;
            this.btn_cart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cart.ForeColor = System.Drawing.Color.White;
            this.btn_cart.Image = ((System.Drawing.Image)(resources.GetObject("btn_cart.Image")));
            this.btn_cart.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_cart.Location = new System.Drawing.Point(644, 12);
            this.btn_cart.Name = "btn_cart";
            this.btn_cart.Size = new System.Drawing.Size(151, 38);
            this.btn_cart.TabIndex = 3;
            this.btn_cart.Text = "Giỏ hàng";
            this.btn_cart.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_cart.UseVisualStyleBackColor = false;
            this.btn_cart.Click += new System.EventHandler(this.btn_cart_Click);
            // 
            // btn_ls
            // 
            this.btn_ls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_ls.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ls.FlatAppearance.BorderSize = 0;
            this.btn_ls.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ls.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ls.ForeColor = System.Drawing.Color.White;
            this.btn_ls.Image = ((System.Drawing.Image)(resources.GetObject("btn_ls.Image")));
            this.btn_ls.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ls.Location = new System.Drawing.Point(474, 12);
            this.btn_ls.Name = "btn_ls";
            this.btn_ls.Size = new System.Drawing.Size(164, 38);
            this.btn_ls.TabIndex = 3;
            this.btn_ls.Text = "Lịch sử mua";
            this.btn_ls.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_ls.UseVisualStyleBackColor = false;
            this.btn_ls.Click += new System.EventHandler(this.btn_ls_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_search.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_search.BackgroundImage")));
            this.btn_search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_search.FlatAppearance.BorderSize = 0;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.Location = new System.Drawing.Point(416, 12);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(52, 38);
            this.btn_search.TabIndex = 3;
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(0, 89);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 100);
            this.panel3.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(3, 86);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 100);
            this.panel2.TabIndex = 1;
            // 
            // txt_search
            // 
            this.txt_search.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.txt_search.Location = new System.Drawing.Point(9, 12);
            this.txt_search.Multiline = true;
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(401, 38);
            this.txt_search.TabIndex = 2;
            this.txt_search.Text = "Bạn tìm gì?";
            this.txt_search.Click += new System.EventHandler(this.txt_search_Click);
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(193)))), ((int)(((byte)(150)))));
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.Controls.Add(this.groupBox3);
            this.panel4.Controls.Add(this.groupBox1);
            this.panel4.Controls.Add(this.btn_delfil);
            this.panel4.Controls.Add(this.btn_filter);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel4.Location = new System.Drawing.Point(-1, 58);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(221, 611);
            this.panel4.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cb_sort);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox3.Location = new System.Drawing.Point(14, 514);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(198, 82);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sắp xếp";
            // 
            // cb_sort
            // 
            this.cb_sort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_sort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_sort.FormattingEnabled = true;
            this.cb_sort.Items.AddRange(new object[] {
            "Giá từ thấp đến cao",
            "Giá từ cao đến thấp"});
            this.cb_sort.Location = new System.Drawing.Point(3, 29);
            this.cb_sort.Name = "cb_sort";
            this.cb_sort.Size = new System.Drawing.Size(195, 26);
            this.cb_sort.TabIndex = 0;
            this.cb_sort.SelectedIndexChanged += new System.EventHandler(this.cb_sort_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cb_hang);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cb_gia);
            this.groupBox1.Controls.Add(this.cb_rom);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.chb_rom);
            this.groupBox1.Controls.Add(this.cb_ram);
            this.groupBox1.Controls.Add(this.chb_ram);
            this.groupBox1.Controls.Add(this.chb_hang);
            this.groupBox1.Controls.Add(this.chb_gia);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(9, 98);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(203, 335);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bộ lọc";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(81, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 22);
            this.label1.TabIndex = 7;
            this.label1.Text = "ROM (GB)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(83, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "RAM (GB)";
            // 
            // cb_hang
            // 
            this.cb_hang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_hang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_hang.FormattingEnabled = true;
            this.cb_hang.Items.AddRange(new object[] {
            "Apple",
            "Samsung",
            "Vivo",
            "OPPO",
            "Nokia",
            "Realme",
            "Xiaomi"});
            this.cb_hang.Location = new System.Drawing.Point(48, 61);
            this.cb_hang.Name = "cb_hang";
            this.cb_hang.Size = new System.Drawing.Size(152, 33);
            this.cb_hang.TabIndex = 0;
            this.cb_hang.SelectedIndexChanged += new System.EventHandler(this.cb_hang_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(95, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 22);
            this.label3.TabIndex = 7;
            this.label3.Text = "Giá";
            // 
            // cb_gia
            // 
            this.cb_gia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_gia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_gia.FormattingEnabled = true;
            this.cb_gia.Items.AddRange(new object[] {
            "Dưới 2 triệu",
            "Từ 2 - 4 triệu",
            "Từ 4 - 7 triệu",
            "Từ 7 - 13 triệu",
            "Từ 13 - 20 triệu",
            "Trên 20 triệu"});
            this.cb_gia.Location = new System.Drawing.Point(48, 128);
            this.cb_gia.Name = "cb_gia";
            this.cb_gia.Size = new System.Drawing.Size(152, 33);
            this.cb_gia.TabIndex = 0;
            this.cb_gia.SelectedIndexChanged += new System.EventHandler(this.cb_gia_SelectedIndexChanged);
            // 
            // cb_rom
            // 
            this.cb_rom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_rom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_rom.FormattingEnabled = true;
            this.cb_rom.Items.AddRange(new object[] {
            "32",
            "64",
            "128",
            "256",
            "512",
            "1024"});
            this.cb_rom.Location = new System.Drawing.Point(45, 276);
            this.cb_rom.Name = "cb_rom";
            this.cb_rom.Size = new System.Drawing.Size(152, 33);
            this.cb_rom.TabIndex = 0;
            this.cb_rom.SelectedIndexChanged += new System.EventHandler(this.cb_gia_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(95, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 22);
            this.label2.TabIndex = 7;
            this.label2.Text = "Hãng";
            // 
            // chb_rom
            // 
            this.chb_rom.AutoSize = true;
            this.chb_rom.Location = new System.Drawing.Point(2, 285);
            this.chb_rom.Name = "chb_rom";
            this.chb_rom.Size = new System.Drawing.Size(18, 17);
            this.chb_rom.TabIndex = 6;
            this.chb_rom.UseVisualStyleBackColor = true;
            // 
            // cb_ram
            // 
            this.cb_ram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_ram.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_ram.FormattingEnabled = true;
            this.cb_ram.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "6 ",
            "8",
            "12"});
            this.cb_ram.Location = new System.Drawing.Point(48, 199);
            this.cb_ram.Name = "cb_ram";
            this.cb_ram.Size = new System.Drawing.Size(152, 33);
            this.cb_ram.TabIndex = 0;
            this.cb_ram.SelectedIndexChanged += new System.EventHandler(this.cb_gia_SelectedIndexChanged);
            // 
            // chb_ram
            // 
            this.chb_ram.AutoSize = true;
            this.chb_ram.Location = new System.Drawing.Point(5, 208);
            this.chb_ram.Name = "chb_ram";
            this.chb_ram.Size = new System.Drawing.Size(18, 17);
            this.chb_ram.TabIndex = 6;
            this.chb_ram.UseVisualStyleBackColor = true;
            // 
            // chb_hang
            // 
            this.chb_hang.AutoSize = true;
            this.chb_hang.Location = new System.Drawing.Point(5, 70);
            this.chb_hang.Name = "chb_hang";
            this.chb_hang.Size = new System.Drawing.Size(18, 17);
            this.chb_hang.TabIndex = 6;
            this.chb_hang.UseVisualStyleBackColor = true;
            this.chb_hang.CheckedChanged += new System.EventHandler(this.chb_hang_CheckedChanged);
            // 
            // chb_gia
            // 
            this.chb_gia.AutoSize = true;
            this.chb_gia.Location = new System.Drawing.Point(5, 137);
            this.chb_gia.Name = "chb_gia";
            this.chb_gia.Size = new System.Drawing.Size(18, 17);
            this.chb_gia.TabIndex = 6;
            this.chb_gia.UseVisualStyleBackColor = true;
            // 
            // btn_delfil
            // 
            this.btn_delfil.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_delfil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_delfil.FlatAppearance.BorderSize = 0;
            this.btn_delfil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delfil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delfil.ForeColor = System.Drawing.Color.White;
            this.btn_delfil.Image = ((System.Drawing.Image)(resources.GetObject("btn_delfil.Image")));
            this.btn_delfil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_delfil.Location = new System.Drawing.Point(9, 451);
            this.btn_delfil.Name = "btn_delfil";
            this.btn_delfil.Size = new System.Drawing.Size(96, 57);
            this.btn_delfil.TabIndex = 3;
            this.btn_delfil.Text = "Xóa bộ lọc";
            this.btn_delfil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_delfil.UseVisualStyleBackColor = false;
            this.btn_delfil.Click += new System.EventHandler(this.btn_delfil_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(173)))), ((int)(((byte)(153)))));
            this.btn_filter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_filter.FlatAppearance.BorderSize = 0;
            this.btn_filter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_filter.ForeColor = System.Drawing.Color.White;
            this.btn_filter.Image = ((System.Drawing.Image)(resources.GetObject("btn_filter.Image")));
            this.btn_filter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_filter.Location = new System.Drawing.Point(111, 451);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(93, 57);
            this.btn_filter.TabIndex = 3;
            this.btn_filter.Text = "Lọc";
            this.btn_filter.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_filter.UseVisualStyleBackColor = false;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // il_phones
            // 
            this.il_phones.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("il_phones.ImageStream")));
            this.il_phones.TransparentColor = System.Drawing.Color.Transparent;
            this.il_phones.Images.SetKeyName(0, "0.jpg");
            this.il_phones.Images.SetKeyName(1, "1.jpg");
            this.il_phones.Images.SetKeyName(2, "2.jpg");
            this.il_phones.Images.SetKeyName(3, "3.jpg");
            this.il_phones.Images.SetKeyName(4, "4.jpg");
            this.il_phones.Images.SetKeyName(5, "5.jpg");
            this.il_phones.Images.SetKeyName(6, "6.jpg");
            this.il_phones.Images.SetKeyName(7, "7.jpg");
            this.il_phones.Images.SetKeyName(8, "8.jpg");
            this.il_phones.Images.SetKeyName(9, "9.jpg");
            this.il_phones.Images.SetKeyName(10, "10.jpg");
            this.il_phones.Images.SetKeyName(11, "11.jpg");
            this.il_phones.Images.SetKeyName(12, "12.jpg");
            this.il_phones.Images.SetKeyName(13, "13.jpg");
            this.il_phones.Images.SetKeyName(14, "14.jpg");
            this.il_phones.Images.SetKeyName(15, "15.jpg");
            this.il_phones.Images.SetKeyName(16, "16.jpg");
            this.il_phones.Images.SetKeyName(17, "17.jpg");
            this.il_phones.Images.SetKeyName(18, "18.jpg");
            this.il_phones.Images.SetKeyName(19, "19.jpg");
            this.il_phones.Images.SetKeyName(20, "20.jpg");
            this.il_phones.Images.SetKeyName(21, "21.jpg");
            this.il_phones.Images.SetKeyName(22, "22.jpg");
            this.il_phones.Images.SetKeyName(23, "23.jpg");
            this.il_phones.Images.SetKeyName(24, "24.jpg");
            this.il_phones.Images.SetKeyName(25, "25.jpg");
            this.il_phones.Images.SetKeyName(26, "26.jpg");
            this.il_phones.Images.SetKeyName(27, "27.jpg");
            this.il_phones.Images.SetKeyName(28, "28.jpg");
            this.il_phones.Images.SetKeyName(29, "29.jpg");
            this.il_phones.Images.SetKeyName(30, "30.jpg");
            this.il_phones.Images.SetKeyName(31, "31.jpg");
            this.il_phones.Images.SetKeyName(32, "32.jpg");
            this.il_phones.Images.SetKeyName(33, "33.jpg");
            this.il_phones.Images.SetKeyName(34, "34.jpg");
            this.il_phones.Images.SetKeyName(35, "35.jpg");
            this.il_phones.Images.SetKeyName(36, "36.jpg");
            this.il_phones.Images.SetKeyName(37, "37.jpg");
            this.il_phones.Images.SetKeyName(38, "38.jpg");
            this.il_phones.Images.SetKeyName(39, "39.jpg");
            this.il_phones.Images.SetKeyName(40, "40.jpg");
            this.il_phones.Images.SetKeyName(41, "41.jpg");
            this.il_phones.Images.SetKeyName(42, "42.jpg");
            this.il_phones.Images.SetKeyName(43, "43.jpg");
            this.il_phones.Images.SetKeyName(44, "44.jpg");
            this.il_phones.Images.SetKeyName(45, "45.jpg");
            this.il_phones.Images.SetKeyName(46, "46.jpg");
            this.il_phones.Images.SetKeyName(47, "47.jpg");
            this.il_phones.Images.SetKeyName(48, "48.jpg");
            this.il_phones.Images.SetKeyName(49, "49.jpg");
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(221, 150);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lw_phones
            // 
            this.lw_phones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lw_phones.HideSelection = false;
            this.lw_phones.Location = new System.Drawing.Point(226, 70);
            this.lw_phones.Name = "lw_phones";
            this.lw_phones.Size = new System.Drawing.Size(961, 584);
            this.lw_phones.TabIndex = 4;
            this.lw_phones.UseCompatibleStateImageBehavior = false;
            this.lw_phones.SelectedIndexChanged += new System.EventHandler(this.lw_phones_SelectedIndexChanged_1);
            // 
            // form_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1183, 666);
            this.Controls.Add(this.lw_phones);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "form_home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UIT Phone Store";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ImageList il_phones;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_ls;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Button btn_cart;
        private System.Windows.Forms.ComboBox cb_sort;
        private System.Windows.Forms.ComboBox cb_hang;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_gia;
        private System.Windows.Forms.Button btn_delfil;
        private System.Windows.Forms.CheckBox chb_gia;
        private System.Windows.Forms.CheckBox chb_hang;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chb_ram;
        private System.Windows.Forms.ComboBox cb_ram;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_recent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_rom;
        private System.Windows.Forms.CheckBox chb_rom;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView lw_phones;
    }
}

