﻿namespace TH02
{


    partial class DataSet1
    {
        partial class DataTable1DataTable
        {
        }
    }
}
