﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace TH02
{
    internal class cart
    {
        private static int n;
        private static DataTable dt;
        public static void Khoitao()
        {
            n = 1;
            dt = new DataTable();
            dt.Columns.Add("IDDH", typeof(string));
            //dt.Columns.Add
            dt.Columns.Add("Tongtien", typeof(decimal));
            dt.Columns.Add("Phantram", typeof(decimal));
            dt.Columns.Add("Phaitra", typeof(decimal));
            dt.Columns.Add("Voucher", typeof(string));
            dt.Columns.Add("Diachi", typeof(string));

            dt.Columns.Add("Thoigiangiaohang", typeof(string));
            dt.Columns.Add("PTTT", typeof(string));
            dt.Columns.Add("DT", typeof(string));

            dt.Columns.Add("Tinhtrang", typeof (string));
            dt.Rows.Add("DH10001", 26000000, 0.2, 24000000, "", "Q1", "17/10/22", "Ví điện tử", "099999999", "Đang giao");
            dt.Rows.Add("DH10002", 25000000, 0.1, 24000000, "", "Q1", "17/10/22", "Ví điện tử", "099999999", "Đã giao");

        }
        public static string GetID()
        {
            return "DH" + n.ToString();
        }
        public static DataTable get()
        {
            return dt;
        }
        public static void UpdateTinhtrang(string iddh, string tt)
        {
            DataRow[] dr = dt.Select(string.Format("IDDH = '{0}'", iddh));
            dr[0]["Tinhtrang"] = tt;
        }
        public static void ThanhToan(string iddh, string voucher, decimal tongtien,decimal phantram, decimal phaitra, string dc, string tg, string pt, string dth, string tt)
        {
            n++;
            dt.Rows.Add(iddh, tongtien, phantram, phaitra, voucher, dc, tg, pt, dth, tt);
        }

        public static void MaGiamGia(string iddh, decimal tt)
        {
            DataRow[] dr = dt.Select(string.Format("IDDH = '{0}'", iddh));
            dr[0]["Tongtien"] = tt;
        }
        public static DataRow GetByIDDH(string iddh)
        {
            DataRow[] dr = dt.Select(string.Format("IDDH = '{0}'", iddh));
            return dr[0];
        }

    }
}
