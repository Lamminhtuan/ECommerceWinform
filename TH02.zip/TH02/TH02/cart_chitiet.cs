﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace TH02
{
    internal class cart_chitiet
    {
        private static DataTable dt;
       
        public static void Khoitao()
        {
           
            dt = new DataTable();
            dt.Columns.Add("IDDH", typeof(string));
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("DT", typeof(string));
            dt.Columns.Add("Gia", typeof(decimal));
            dt.Columns.Add("Soluong", typeof(int));
            dt.Columns.Add("Thanhtien", typeof(decimal));
            dt.Rows.Add("DH10001", 0, "iPhone 14 Pro Max", 28990000, 12, 123213213);
            dt.Rows.Add("DH10001", 1, "iPhone 14 Pro", 28990000, 12, 123213213);
            dt.Rows.Add("DH10002", 0, "iPhone 14 Pro Max", 28990000, 12, 123213213);

        }
        public static void Add(string iddh, int id, string name, decimal gia, int sl)
        {
            decimal thanhtien = gia * sl;
            dt.Rows.Add(new object[] { iddh, id, name, gia, sl, thanhtien });

        }
        public static decimal gettongtien(string iddh)
        {
            decimal n = 0;
            DataRow[] r = dt.Select(String.Format("IDDH='{0}'", iddh));
            for (int i = 0; i < r.Length; i++)
                n += Convert.ToDecimal(r[i]["Thanhtien"].ToString());
            return n;
        }
        public static void Xoa(string iddh, string id)
        {
            DataRow[] dr = dt.Select(string.Format("IDDH = '{0}' AND ID = '{1}'", iddh, id));
            foreach(DataRow r in dr) {
                dt.Rows.Remove(r);
                 }
            
        }
        public static void UpdateSL(string iddh, int id, int sl)
        {
            string ids = id.ToString();
            DataRow[] dr = dt.Select(string.Format("IDDH = '{0}' AND ID = '{1}'", iddh, ids));
            dr[0]["Soluong"] = sl;
            dr[0]["Thanhtien"] = Convert.ToDecimal(dr[0]["Gia"].ToString()) * Convert.ToInt32(dr[0]["Soluong"].ToString());
            
        }
        
        public static DataTable get(string iddh)
        {
            DataTable r_d = new DataTable();
           
            DataRow[] r = dt.Select(String.Format("IDDH='{0}'", iddh));
            if (r.Length > 0)
                r_d = r.CopyToDataTable();
            return r_d;
        }
    }
}
