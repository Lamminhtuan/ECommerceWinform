﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class form_review : Form
    {
        public string iddh { get; set; }
        public form_review()
        {
            InitializeComponent();
        }

        private void form_review_Load(object sender, EventArgs e)
        {
            DataTable dts = cart_chitiet.get(iddh);
            dts.Columns.Remove("IDDH");
            dts.Columns.Remove("Gia");
            dts.Columns.Remove("Soluong");
            dts.Columns.Remove("Thanhtien");
            dt_cmts.DataSource = dts;
          
           

        }

        private void btn_done_Click(object sender, EventArgs e)
        {
           
            foreach (DataGridViewRow dr in dt_cmts.Rows)
            {
                int id = Convert.ToInt32(dr.Cells["ID"].Value);
                string cmt = dr.Cells["Binhluan"].Value.ToString();
                int re = Convert.ToInt32(dr.Cells["Danhgia"].Value);
                comments.AddCmts(id, cmt, re);
            }
            this.Close();
        }
    }
}
