﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace TH02
{
    internal class comments
    {
        private static DataTable dt;
        public static void Khoitao()
        {
            dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Binhluan", typeof(string));
            dt.Columns.Add("Danhgia", typeof(int));
            dt.Rows.Add(0, "Sản phẩm rất tốt", 5);
            dt.Rows.Add(0, "Sản phẩm rất tệ", 1);
            dt.Rows.Add(1, "Sản phẩm rất tệ", 1);
            dt.Rows.Add(1, "Sản phẩm khá tệ", 2);
            dt.Rows.Add(2, "Sản phẩm rất tốt", 5);
        }
        public static DataTable GetCmts(int id)
        {
            DataTable dtr = new DataTable();
            DataRow[] dr = dt.Select(String.Format("ID = '{0}'", id));
            if (dr.Length > 0)
                dtr = dr.CopyToDataTable();
            return dtr;
        }
        public static decimal GetAvg(int id)
        {
            decimal sum = 0;

            DataRow[] dr = dt.Select(String.Format("ID = '{0}'", id));
            if (dr.Length > 0)
            {
                foreach (DataRow d in dr)
                {
                    sum += Convert.ToDecimal(d["Danhgia"].ToString());

                }
                decimal avg = sum / dr.Length;
                return Math.Round(avg * 2, MidpointRounding.AwayFromZero) / 2;
            }
            else
                return -1;
        }
        public static void AddCmts(int id, string cmt, int re)
        {
            dt.Rows.Add(id, cmt, re);
            
        }
    }
}
