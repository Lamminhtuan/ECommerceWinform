﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class form_paycs : Form
    {
        DataTable dt;
        string percent = "0";
        decimal r = 0;
        CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");

        public string iddh { get; set; }
        string v = "Không có";
        decimal tongtien;
        public form_paycs()
        {
            InitializeComponent();
        }

        private void form_paycs_Load(object sender, EventArgs e)
        {
            dt_tggh.MinDate = DateTime.Now;
            dt = cart_chitiet.get(iddh);
            dataGridView1.DataSource = dt;
            CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
            tongtien = cart_chitiet.gettongtien(iddh);
            string gia =tongtien.ToString("C", cul);

        
            txt_tongtien.Text = gia;
        }

        private void btn_apply_Click(object sender, EventArgs e)
        {
            string vo = txt_voucher.Text;
            r = voucher.GiamGia(vo);
            if (r == 0)
            {
                MessageBox.Show("Mã giảm giá không tồn tại!");
                txt_voucher.Text = "";
            }
            else
            {
                MessageBox.Show("Áp dụng thành công!");
                pt_voucher.Visible = true;
                percent = (r * 100).ToString();
                v = txt_voucher.Text;
                lb_voucher.Text = "Bạn đã được giảm giá " + percent + "%!";
                lb_voucher.Visible = true;
                tongtien = tongtien * (1 - r);


                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");


                string gia = String.Format(cul, "{0:c}", tongtien.ToString());
                txt_tongtien.Text = gia;
            }

        }

        private void btn_money_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txt_dc.Text) || String.IsNullOrEmpty(cb_pttt.Text) || String.IsNullOrEmpty(txt_dth.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
            }
            else
            {
                
                DateTime today = DateTime.Today;

                decimal tt = tongtien;
                string dc = txt_dc.Text;
                string pttt = cb_pttt.Text;
                DateTime ngdat = dt_tggh.Value.Date;
                string tg = ngdat.ToString("d");
                string sdt = txt_dth.Text;
                decimal ttt = cart_chitiet.gettongtien(iddh);
                if (today == ngdat)
                    cart.ThanhToan(iddh, v, ttt, r, tt,dc,  tg, pttt, sdt, "Đã giao");
                else
                    cart.ThanhToan(iddh, v, ttt, r,tt, dc, tg, pttt, sdt, "Đang giao");
                
                form_bill fb = new form_bill();
                fb.iddh = iddh;
                fb.dchi = dc;
                fb.pttt= pttt;
                fb.tggh = tg;
                fb.voucher = v;
                fb.sdt = sdt;
                fb.phaitra = String.Format(cul, "{0:c}", txt_tongtien.Text); 
                fb.phantram = percent;
                fb.ShowDialog();
                this.Close();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txt_tongtien_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
