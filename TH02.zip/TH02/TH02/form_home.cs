﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class form_home : Form
    {
        DataTable dt = phones_data.Khoitao();

        public form_home()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comments.Khoitao();
            cart_chitiet.Khoitao();
            clicked.Khoitao();
            voucher.Khoitao();
            cart.Khoitao();
            lw_phones.View = View.LargeIcon;

            lw_phones.LargeImageList = il_phones;
            int n = il_phones.Images.Count;



            for (int i = 0; i < n; i++)
            {
                string name = dt.Rows[i]["DT"].ToString();
                decimal gia_d = Convert.ToDecimal(dt.Rows[i]["Gia"].ToString());
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
                string gia = String.Format(cul, "{0:c}", gia_d);
                int index = Convert.ToInt32(dt.Rows[i]["ID"].ToString());
                lw_phones.Items.Add(name + "\n" + gia, index);
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txt_search_Click(object sender, EventArgs e)
        {
            txt_search.Text = "";
            txt_search.ForeColor = System.Drawing.Color.Black;
        }

  

        private void cb_sort_SelectedIndexChanged(object sender, EventArgs e)
        {
            lw_phones.Items.Clear();
            if (cb_sort.SelectedIndex == 0)
            {


                dt.DefaultView.Sort = "Gia ASC";
                dt = dt.DefaultView.ToTable();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string name = dt.Rows[i]["DT"].ToString();
                    decimal gia_d = Convert.ToDecimal(dt.Rows[i]["Gia"].ToString());
                    CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
                    string gia = String.Format(cul, "{0:c}", gia_d);
                    int index = Convert.ToInt32(dt.Rows[i]["ID"].ToString());
                    lw_phones.Items.Add(name + "\n" + gia, index);
                }
            }
            else
            {
                dt.DefaultView.Sort = "Gia DESC";
                dt = dt.DefaultView.ToTable();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string name = dt.Rows[i]["DT"].ToString();
                    decimal gia_d = Convert.ToDecimal(dt.Rows[i]["Gia"].ToString());
                    CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
                    string gia = String.Format(cul, "{0:c}", gia_d);
                    int index = Convert.ToInt32(dt.Rows[i]["ID"].ToString());
                    lw_phones.Items.Add(name + "\n" + gia, index);
                }
            }

        }

        private void btn_filter_Click(object sender, EventArgs e)
        {

            int from = -1, to = 100000000;
            int from_ram = -1, to_ram = 1000;
            int from_rom = -1, to_rom = 2000;
            string hang = "";
            int n = 0;
            dt = phones_data.Khoitao();
            if (chb_hang.Checked == true)
            {
                hang = cb_hang.Text;

            }

            if (chb_gia.Checked == true)
            {
                if (cb_gia.SelectedIndex == 0)
                {
                    from = 0;
                    to = 2000000;
                }
                else if (cb_gia.SelectedIndex == 1)
                {
                    from = 2000000;
                    to = 4000000;
                }
                else if (cb_gia.SelectedIndex == 2)
                {
                    from = 4000000;
                    to = 7000000;
                }
                else if (cb_gia.SelectedIndex == 3)
                {
                    from = 7000000;
                    to = 13000000;
                }
                else if (cb_gia.SelectedIndex == 4)
                {
                    from = 13000000;
                    to = 20000000;
                }
                else
                {
                    from = 20000000;

                }
            }
            if (chb_ram.Checked == true)
            {

                from_ram = Convert.ToInt32(cb_ram.Text);
                to_ram = from_ram;



            }
            if (chb_rom.Checked == true)
            {
                from_rom = Convert.ToInt32(cb_rom.Text);
                to_rom = from_rom;

            }

            string query = string.Format("Hang like '%{0}%' and Gia >= '{1}' and Gia <= '{2}' and RAM >= '{3}' and RAM <= '{4}' and ROM >= '{5}' and ROM <= '{6}'", hang, from, to, from_ram, to_ram, from_rom, to_rom);




            DataRow[] result = dt.Select(query);
            if (result.Length > 0)
            {

                dt = result.CopyToDataTable();
                n = dt.Rows.Count;
            }

            lw_phones.Items.Clear();
            for (int i = 0; i < n; i++)
            {
                string name = dt.Rows[i]["DT"].ToString();
                decimal gia_d = Convert.ToDecimal(dt.Rows[i]["Gia"].ToString());
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
                string gia = String.Format(cul, "{0:c}", gia_d);
                int index = Convert.ToInt32(dt.Rows[i]["ID"].ToString());
                lw_phones.Items.Add(name + "\n" + gia, index);

            }
        }

        private void btn_delfil_Click(object sender, EventArgs e)
        {
            dt = phones_data.Khoitao();
            lw_phones.Items.Clear();
            for (int i = 0; i < il_phones.Images.Count; i++)
            {
                string name = dt.Rows[i]["DT"].ToString();
                decimal gia_d = Convert.ToDecimal(dt.Rows[i]["Gia"].ToString());
                CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
                string gia = String.Format(cul, "{0:c}", gia_d);
                int index = Convert.ToInt32(dt.Rows[i]["ID"].ToString());
                lw_phones.Items.Add(name + "\n" + gia, index);
            }
            cb_hang.SelectedItem = null;
            cb_hang.Text = "";
            cb_gia.SelectedItem = null;
            cb_gia.Text = "";
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txt_search.Text)) {
                string namep = txt_search.Text;
                string query = string.Format("DT like'%{0}%'", namep);
                DataRow[] result = dt.Select(query);
                if (result.Length > 0)
                    dt = result.CopyToDataTable();
                lw_phones.Items.Clear();
                for (int i = 0; i < result.Length; i++)
                {
                    string name = dt.Rows[i]["DT"].ToString();
                    decimal gia_d = Convert.ToDecimal(dt.Rows[i]["Gia"].ToString());
                    CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
                    string gia = String.Format(cul, "{0:c}", gia_d);
                    int index = Convert.ToInt32(result[i]["ID"].ToString());
                    lw_phones.Items.Add(name + "\n" + gia, index);
                }
            }
            else
            {
                dt = phones_data.Khoitao();
            }
        }

        private void cb_hang_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cb_gia_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chb_hang_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lw_phones_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_cart_Click(object sender, EventArgs e)
        {
            form_cart ct = new form_cart();
            ct.ShowDialog();
        }

        private void btn_ls_Click(object sender, EventArgs e)
        {
            form_history ls = new form_history();
            ls.ShowDialog();
        }

        private void btn_recent_Click(object sender, EventArgs e)
        {
            form_clicked ff = new form_clicked();
            ff.ShowDialog();
        }

        private void lw_phones_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (lw_phones.SelectedItems.Count > 0)
            {

                int index = lw_phones.SelectedIndices[0];
                form_phone f = new form_phone();
                f.name = dt.Rows[index]["DT"].ToString();
                f.gia = Convert.ToDecimal(dt.Rows[index]["Gia"].ToString());

                f.screen = dt.Rows[index]["Screen"].ToString();
                f.os = dt.Rows[index]["OS"].ToString();
                f.camera = dt.Rows[index]["Camera"].ToString();
                f.selfie = dt.Rows[index]["Selfie"].ToString();
                f.chip = dt.Rows[index]["Chip"].ToString();
                f.ram = dt.Rows[index]["RAM"].ToString();
                f.rom = dt.Rows[index]["ROM"].ToString();
                f.pin = dt.Rows[index]["Pin"].ToString();
                int id = Convert.ToInt32(dt.Rows[index]["ID"].ToString());
                clicked.addclicked(id);
                f.id = id;
                f.ShowDialog();
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
