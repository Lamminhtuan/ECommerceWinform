﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace TH02
{
    internal class clicked
    {
        private static DataTable dt;
        public static void Khoitao()
        {
            dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("DT", typeof(string));
            dt.Columns.Add("Hang", typeof(string));
            dt.Columns.Add("Gia", typeof(decimal));
            dt.Columns.Add("Screen", typeof(string));
            dt.Columns.Add("OS", typeof(string));
            dt.Columns.Add("Camera", typeof(string));
            dt.Columns.Add("Selfie", typeof(string));
            dt.Columns.Add("Chip", typeof(string));
            dt.Columns.Add("RAM", typeof(int));
            dt.Columns.Add("ROM", typeof(int));
            dt.Columns.Add("Pin", typeof(string));

        }
        public static DataTable Get()
        {
            return dt;
        }
        public static void addclicked(int id)
        {
            DataRow[] dr = phones_data.GetPhone(id);
             foreach(DataRow d in dr){
                dt.ImportRow(d);
            }
        }
    }
}
