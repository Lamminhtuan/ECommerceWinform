ZXing C# Port

** There is now an official port of this project on codeplex http://zxingnet.codeplex.com/ ** 

It's recommended that you uninstall this package and use the ZXing.Net package for further updates.